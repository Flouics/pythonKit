local PanelUI=require("gameui.PanelUI")
local UITools = require("zeromvc.ui.UITools")

return function (__Class)
function __Class:using(yamenProxy)
    self.yamenProxy = yamenProxy
    self.universeProxy= self.zero:getProxy("game.universe.UniverseProxy")
    local stu=PanelUI:new("yamen.oneKeyConfirmNew",true)
    stu:offset(display.cx,display.cy)
    self.stu=stu
    self.canClose = false
    self.level = 0

    self.box1 = stu:getChild("txt3","select1")
    self.box2 = stu:getChild("txt3","select2")
    self.box3 = stu:getChild("txt3","select3")

    UICommon.openDialogAction(stu)
    local function closeHd()
        UICommon.closeDialogAction(stu,handler(self,self.hideSelf))
    end
    stu:addEvent("close",closeHd)

    local function yesHd()
        self:command("JediYanmenCommand.oneKeyPlayNew",self.level)
        UICommon.closeDialogAction(stu,handler(self,self.hideSelf))
    end
    stu:addEvent("yes",yesHd)

    local function checkBoxHd1(stu,event,sender,clickType)
        self.level = 1
        
        if self.box1:isSelected() then
            self.box2:setSelected(false)
            self.box3:setSelected(false)
        else
            self.box1:setSelected(true)
            self.box2:setSelected(false)
            self.box3:setSelected(false)
        end
    end
    stu:addEvent("select1",checkBoxHd1)

    local function checkBoxHd2(stu,event,sender,clickType)
        self.level = 2
        if self.box2:isSelected() then
            self.box1:setSelected(false)
            self.box3:setSelected(false)
        else
            self.box2:setSelected(true)
            self.box1:setSelected(false)
            self.box3:setSelected(false)
        end
    end
    stu:addEvent("select2",checkBoxHd2)

    local function checkBoxHd3(stu,event,sender,clickType)
        self.level = 3
        if self.box3:isSelected() then
            self.box1:setSelected(false)
            self.box2:setSelected(false)
        else
            self.box3:setSelected(true)
            self.box1:setSelected(false)
            self.box2:setSelected(false)
        end
    end
    stu:addEvent("select3",checkBoxHd3)

    stu:getChild("txt1"):setString(lang("yamen.Tip6"))
    stu:getChild("txt2"):setString(lang("yamen.Tip7"))
    return stu
end

end