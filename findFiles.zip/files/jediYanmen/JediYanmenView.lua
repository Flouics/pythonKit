local PanelUI = require("gameui.PanelUI")
local UITools = require("zeromvc.ui.UITools")
return function (__Class)
    
    function __Class:using(proxy, TimeProxy)
        self.timeProxy = TimeProxy
        self.proxy = proxy;
        self.playerProxy = self.zero:getProxy("game.player.PlayerProxy")
        self.unionProxy = self.zero:getProxy("game.union.UnionProxy")
        self.activityProxy = self.zero:getProxy("game.activity.ActivityProxy")
        local stu = PanelUI:new("jediYanmen.jediYanmenView")
        self.stu = stu;
        stu:offset(0, 0)
        self.listView = self.stu:getChild("node1", "listView")
        self.zero:hide("game.jediYanmen.jediRankView")
        self.zero:hide("game.home.HomeView")
        stu:addEvent("close", function()
            self:hideSelf()
            self.zero:show("game.home.HomeView")
        end)
        stu:addEvent("detail",function ( ... )
            self:command("JediYanmenCommand.showOwner",6,self.myClub)
        end)
        stu:addEvent("chatBtn",function ( ... )
            self:command("JediYanmenCommand.showChatView")
        end)
        stu:addEvent("explain",function ( ... )
            self.zero:command("game.help.HelpCommand.showHelp","jediYanmen")
        end)
        self.zige = false -- 有没有资格参赛
        self.posX, self.posY = self.stu:getChild("node1","imgNode"):getPosition()
        self.parm = 1
        self.stu:getChild("node2"):setVisible(true)
        self:updateJediYamen()
        return stu
    end

    function __Class:updateJediYamen( ... )
        self.jiesuan = false
        self.data = nil
        self.strChatMes = nil
        self:isHaveZige()
        self:initWidget()
        self:initWidget2()
        self:upListView()
        self:showTishi()
        self:upTime_jdyamen()
    end

    function __Class:isHaveZige( )
        local user = self.proxy.jdyamen.user
        -- for i,v in ipairs(self.proxy.jdyamen.userList) do
        --     if v.u == self.playerProxy.user.uid then
        --         self.zige = true
        --     end
        -- end
        if  user.qualify == 0 then
            self.zige = false
        else
            self.zige = true
        end
    end

    function __Class:showTishi( ... )
        local x1, y1, eTime,num =self:setCountTime()
        local user = self.proxy.jdyamen.user
        
        self.stu:getChild("node2","txt1"):removeAllChildren()
        self.stu:getChild("node2","txt2"):removeAllChildren()
        local state = self.proxy.jdyamen.cfg.state
        if state == 3 then
            self.stu:getChild("node2","txt1"):setVisible(false)
            self.stu:getChild("node2","txt2"):setString(lang("grave.endhd"))
        else
            if self.proxy.jdyamen.cfg.zd_state == 0 then --等待阶段
                if self.zige == true then
                    self.stu:getChild("node2","txt2"):setString(lang("juediyamen.qingshaohou"))
                else
                    self.stu:getChild("node2","txt2"):setString(lang("juediyamen.notqualification"))
                end
                self:setRetchText2("              "..lang("juediyamen.huodongweikai"),"","",self.stu:getChild("node2","txt1"))
            -- elseif num == -10 then -- 活动结束
            --     self.stu:getChild("node2","txt1"):setVisible(false)
            --     self.stu:getChild("node2","txt2"):setString(lang("grave.endhd"))
            -- elseif num == -100 then -- 活动结束
            --     self.stu:getChild("node2","txt1"):setVisible(false)
            --     self.stu:getChild("node2","txt2"):setString(lang("grave.endhd"))
            elseif num == -1 or y1 <=0 then -- 结算阶段
                if self.zige == true then
                    self.stu:getChild("node2","txt1"):setString("")
                    self:setRetchText2("              "..lang("juediyamen.currRanks").." ",user.rid,"",self.stu:getChild("node2","txt1"))
                else
                    self.stu:getChild("node2","txt1"):setString("         "..lang("juediyamen.notqualification"))
                end
                self.stu:getChild("node2","txt2"):setString(lang("juediyamen.actOver"))
            elseif self.proxy.jdyamen.cfg.zd_state == 1 then --比赛阶段
                if self.zige == true then -- 有资格
                    local win = user.win
                    if win == 0 then  -- 已淘汰\
                        self.stu:getChild("node2","txt1"):setString("")
                        self:setRetchText2(lang("juediyamen.currRanks"),user.rid,"         "..lang("juediyamen.alreadyOut"),self.stu:getChild("node2","txt1"))
                    else
                        self.stu:getChild("node2","txt1"):setString(lang("juediyamen.currRanks")..user.rid.."         "..lang("juediyamen.currScore")..user.score)
                    end
                else -- 无资格
                    self.stu:getChild("node2","txt1"):setString("         "..lang("juediyamen.notqualification"))
                end
                self.stu:getChild("node2","txt2"):setString(lang("juediyamen.taotaipaiming")..self.paiming..lang("juediyamen.yixiawanjia"))
            end
        end
        self.stu:getChild("node2","bg"):addClickEventListener(function ( ... )
            if (self.proxy.jdyamen.cfg.zd_state == 1) or self.proxy.jdyamen.cfg.zd_state == 2  or state == 3 then
                self.stu:getChild("node2"):setVisible(false)
            end
        end)

        self.stu:getChild("node1","menpai"):addClickEventListener(function ( ... )
            self.listView:scrollToItemHor(self.scrollIndex,1)
        end)
    end

    function __Class:setRetchText2( tex1, tex2 ,txt3, item)
        local rtes = {}
        table.insert(rtes, UICommon.RET(tex1,24, cc.c3b(255,255,255)) )
        table.insert(rtes, UICommon.RET(tex2,24, cc.c3b(0,255,0)) )
        table.insert(rtes, UICommon.RET(txt3,24, cc.c3b(255,0,0)) )
        UICommon.createRichText(item, rtes)
        -- item:setString("")
    end

    function __Class:upTime_jdyamen( ... )
        self:setactTime()
        if self.setCooling == true then
            self:setCoolings()
        end
    end

    function __Class:setCoolings( ... ) --冷却倒计时
        local info =self.proxy.jdyamen.info
        if not info then
            return
        end
        local time = info.cd.next
        time =  time -  self.timeProxy:getTime()
        if time < 0 then
            return
        end
        time = self.timeProxy:showTime(info.cd)
        self.stu:getChild("node1","randomBtn","Text_101"):setString(time)
    end

    function __Class:updateData( ... )
        -- self.proxy.jdyamen.cfg.lun = 3
        self.lunshu = self.proxy.jdyamen.cfg.lun
        -- print("ssssssssssssssssssssssss",self.proxy.jdyamen.cfg.lun )
        self.paiming = 0
        self:setactTime()
    end

    function __Class:setRetchText( tex1, tex2 ,txt3, item)
        local rtes = {}
        table.insert(rtes, UICommon.RET(tex1,24, cc.c3b(255,255,255)) )
        table.insert(rtes, UICommon.RET(tex2,24, cc.c3b(0,255,0)) )
        table.insert(rtes, UICommon.RET(txt3,24, cc.c3b(255,255,255)) )
        UICommon.createRichText(item, rtes)
        -- item:setString("")
    end
    
    function __Class:initWidget()
        -- local parm = 1
        local imgNode = self.stu:getChild("node1", "imgNode")
        local flagImg = self.stu:getChild("node1", "lookMore", "flagImg")
        -- local posX, posY = imgNode:getPosition()
        local function lookMore(...)
            imgNode:stopAllActions()
            self.stu:getChild("node1", "lookMore"):setTouchEnabled(false)
            local act1 = cc.MoveTo:create(0.2, cc.p(self.posX, self.posY + 1030))
            local act2 = cc.MoveTo:create(0.05, cc.p(self.posX, self.posY + 980))
            local act3 = cc.MoveTo:create(0.2, cc.p(self.posX, self.posY))
            local act4 = cc.MoveTo:create(0.05, cc.p(self.posX, self.posY + 1030))
            local function callfunc( ... )
                self.stu:getChild("node1", "lookMore"):setTouchEnabled(true)
                if self.parm == 2 then
                    self.stu:getChild("node1","imgNode","bgBtn"):setVisible(true)
                end
            end 
            if self.parm == 1 then
                local seq1 = cc.Sequence:create(act1, act2,cc.CallFunc:create(callfunc))
                imgNode:runAction(seq1)
                flagImg:setScaleY(-1)
                self.parm = 2
            else
                local seq1 = cc.Sequence:create(act4, act3,cc.CallFunc:create(callfunc))
                imgNode:runAction(seq1)
                flagImg:setScaleY(1)
                self.parm = 1
                self.stu:getChild("node1","imgNode","bgBtn"):setVisible(false)
            end
        end
        self.stu:getChild("node1","imgNode","bgBtn"):addClickEventListener(lookMore)
        self.stu:getChild("node1", "lookMore"):addClickEventListener(lookMore)

        local function randomBtn( ... )
            if self.proxy:isHaveZigeChallenge() then
                return
            end
            if not self.proxy.jdyamen.info then
                print("errro  randomBtn")
                return 
            end
            local state = self.proxy.jdyamen.info.state

            if  state == 0 then
                self:command("JediYanmenCommand.randomChallenge")
            elseif state == 1 then

            elseif state == 2 then
                self:command("JediYanmenCommand.jdPiZhun")
            elseif state == 3 then
                self.zero:command("game.bag.BagCommand.thingSure",123,
                lang("yamen.usecsl"),1,
                function ()
                    self:command("JediYanmenCommand.chushi")
                end)
            elseif state == 4 then

            elseif state == 11 then
                self:command("JediYanmenCommand.clickHero")
            elseif state == 12 then
                self:command("JediYanmenCommand.clickHero")
            elseif state == 13 then
                self:command("JediYanmenCommand.clickHero")
            elseif state == 14 then
                self:command("JediYanmenCommand.clickHero")
            elseif state == 15 then
                self:command("JediYanmenCommand.clickHero")
            end
        end 
        UICommon.buttonClickEnabled(self.stu:getChild("node1", "randomBtn"), true)
        local user = self.proxy.jdyamen.user
        self.setCooling = false
        self.stu:getChild("node1","randomBtn"):addClickEventListener(randomBtn)
        if self.proxy.jdyamen.info then
                local state = self.proxy.jdyamen.info.state
                if state == 2 or state == 11 or state == 12  or state == 13 or state == 14 or state == 15 then 
                    self.stu:getChild("node1","randomBtn","Text_101"):setString(lang("juediyamen.challengeCurr"))
                elseif state == 3 then
                    self.stu:getChild("node1","randomBtn","Text_101"):setString(lang("juediyamen.ewaiChallenge"))
                elseif state == 4 then
                    self.stu:getChild("node1","randomBtn","Text_101"):setString(lang("juediyamen.cishuNone"))
                    UICommon.buttonClickEnabled(self.stu:getChild("node1", "randomBtn"), false)
                elseif state == 1 then
                    UICommon.buttonClickEnabled(self.stu:getChild("node1", "randomBtn"), false)
                    self.setCooling = true
                elseif state == 2 then
                    self:command("JediYanmenCommand.challengeOne")
                else
                    self.stu:getChild("node1","randomBtn","Text_101"):setString(lang("juediyamen.randomChallenge"))
                end
        end
        local servarTime = self.timeProxy:getTime() 

        if self.zige == false then
            UICommon.buttonClickEnabled(self.stu:getChild("node1", "randomBtn"), false)
            self.stu:getChild("node1","randomBtn","Text_101"):setString(lang("juediyamen.notQuali"))
        elseif user.win == 0 then
            UICommon.buttonClickEnabled(self.stu:getChild("node1", "randomBtn"), false)
            self.stu:getChild("node1","randomBtn","Text_101"):setString(lang("juediyamen.alreayPass"))
        elseif  self.proxy.jdyamen.cfg.zd_state == 0 or self.proxy.jdyamen.cfg.zd_state == 2 then
            UICommon.buttonClickEnabled(self.stu:getChild("node1", "randomBtn"), false)
            self.stu:getChild("node1","randomBtn","Text_101"):setString(lang("juediyamen.xiuxizhong"))
        end

         local state = self.proxy.jdyamen.cfg.state
        if state == 3 then
             UICommon.buttonClickEnabled(self.stu:getChild("node1", "randomBtn"), false)
              self.stu:getChild("node1","randomBtn","Text_101"):setString(lang("grave.endhd"))
        end

        self.gobalSwitchProxy = self.zero:getProxy("game.switch.GobalSwitchProxy")
        if self.gobalSwitchProxy:getSwitch("beast") ~= true then  --灵兽提示开关
             self.stu:getChild("node2","txt3"):setVisible(false)
        end
    end

    function __Class:setpaiming( )
        local paiming2

        if self.lunshu then
            if self.proxy.jdyamen.cfg.zd_state == 0 then
                paiming2 = -2 
            elseif self.proxy.jdyamen.cfg.zd_state == 1 then
                paiming2 = self.proxy.jdyamen.cfg.lunshu[self.lunshu].num 
            else
                paiming2 = -1
            end
        else
            paiming2 = -1
        end

        return paiming2
    end
    
    function __Class:setactTime(...)
        local x1, y1, eTime,num = self:setCountTime()
        local state = self.proxy.jdyamen.cfg.state

        if num ~= -1 and state ~=3 then
            self.stu:getChild("node1", "time"):setVisible(true)
            self.stu:getChild("node1", "time_0"):setVisible(true)
            self.stu:getChild("node1", "time"):setString(x1)
        else
            self.stu:getChild("node1", "time"):setVisible(false)
            self.stu:getChild("node1", "time_0"):setVisible(false)
        end

        local data = self.jediYanmenProxy.chatMes
        if next(data) then
            if self.strChatMes ~= data[#data].msg then
                self.strChatMes = data[#data].msg
                self:setRetchText(data[#data].user.name.."："..data[#data].msg,"","",self.stu:getChild("node1","chatTxt"))
            end
        end
        
    end

    function __Class:setpaimingParm( state, parm,paiming2)
        if state == 3 then
            self:setRetchText("            "..lang("grave.endhd"),"","",self.stu:getChild("node1","txt1"))
        elseif parm == -2 then
            self.paiming  = paiming2
            self.stu:getChild("node1", "time_0"):setString(lang("juediyamen.start",""))
            self:setRetchText("              "..lang("juediyamen.huodongweikai"),"","",self.stu:getChild("node1","txt1"))
        elseif parm == -1 then
            self:setRetchText("            "..lang("juediyamen.actOver"),"","",self.stu:getChild("node1","txt1"))
        else
            self.stu:getChild("node1", "time_0"):setString(lang("juediyamen.taotaitime"))
            if self.paiming ~= paiming2 then
                self.paiming = paiming2
                self.stu:getChild("node1","txt1"):removeAllChildren()
                self:setRetchText(lang("juediyamen.taotaipaiming"),self.paiming,lang("juediyamen.yixiawanjia"),self.stu:getChild("node1","txt1"))
            end
        end
    end

    --倒计时
    function __Class:setCountTime(...)
        local time3
        local str = ""
        local servarTime = self.timeProxy:getTime() 

        local paiming2,parm = self.proxy:setpaiming()
        local state = self.proxy.jdyamen.cfg.state
        self:setpaimingParm(state, parm,paiming2)

        local num,overtime = self.proxy:setCount()
        local nowTime = overtime

        local eTime = 0
        
        local cd = {}
        cd["label"] = "qixitemp"
        cd["next"] = nowTime
        local nowTime = self.timeProxy:getLong(cd)
        time3 = nowTime > 0 and str..self.timeProxy:showTime(cd) or ""
        if overtime and  nowTime <= 0 and nowTime > -120 and num ~= -2 and num ~= -1 then
            self.stu:getChild("bg"):setVisible(true)
            local showPool = self.zero.showPool
            if self.jiesuan == false then
                self.jiesuan = true
                for i,v in pairs(showPool) do
                    local arrName = string.split(i,".")
                    if arrName[2] == "jediYanmen" and arrName[3] ~= "JediYanmenView" then
                        self.zero:hide(i)
                    end
                end
            end
        elseif overtime and servarTime  >  overtime and self.jiesuan == true then 
            self.jiesuan = false
            self:command("JediYanmenCommand.showJediYamen",true)
        else
            self.jiesuan = false
            self.stu:getChild("bg"):setVisible(false)
        end

        return time3, nowTime, eTime,num
    end
    
    function __Class:upListView(...)
        local people = {}
        local arr2 = clone(self.proxy.jdyamen.clublist)
        -- local arr3 = clone(arr2)
        -- table.insertto(arr2,arr3)
        --  table.insertto(arr2,arr3)
        self.exist = 0
        for i,v in ipairs(arr2) do
            if v.sy >= 1 then
                self.exist = self.exist + 1
            end
        end
       
        self.index = 0
        local function setClub( ... )
            local arr1 = {}
            for i= 1,#arr2 do
                table.insert(arr1,arr2[i])           
                if i % 10 == 0 or  i == #arr2 then
                    table.insert(people,arr1)   
                    arr1 = {}
                end
            end
        end
        setClub()
        self.data = people

        self.stu:getChild("node1","leftFlag"):setVisible(false)
        if #people > 1 then
            self.stu:getChild("node1","rightFlag"):setVisible(true)
        else
            self.stu:getChild("node1","rightFlag"):setVisible(false)
        end
        local user = self.proxy.jdyamen.user
        for i,v in ipairs(self.data) do
            for k,val in ipairs(v) do
                if val.cid == user.cid then
                    self.myClub = val
                    self.scrollIndex = i
                    if self.scrollIndex ~= 1 then
                        self.stu:getChild("node1","menpai"):setVisible(true)
                    end
                end
            end
        end

        local itemName = "jediYanmen.jediSubItem.jediItem"
        local function getItem(v)
            local stu = require(itemName).create()
            local item = stu.box
            -- local posx = item:getChildByName("qufuNumber"):getPositionX()
            -- item:getChildByName("qufuNumber"):setPositionX(posx + 230)
            item:removeSelf(true)
            item.setData = function (_item, v)
                self:setItem(item, v)
            end
            return item
        end
        local TestItem = require(itemName).create()
        self.listView:plus(TestItem.box:getContentSize(), getItem)
        self.listView:upList(self.data)
        self.isCanGetMes = true
        local listViewWidth = TestItem.box:getContentSize().width
        self.indexPos = nil
        -- self.scrollIndex = 0
        local x = 0
        local function scrollViewEvent(sender, evenType)
            if #arr2 <= 10 then
                return
            end
            sender:scrollHd(evenType)
            local itemIn = math.abs(sender:getInnerContainerPosition().x/listViewWidth) + 1
            if  itemIn and itemIn ~= self.indexPos and self.scrollIndex then
                self.indexPos = itemIn
                if self.indexPos == self.scrollIndex then
                    self.stu:getChild("node1","menpai"):setVisible(false)
                else
                    self.stu:getChild("node1","menpai"):setVisible(true)
                end
            end
            if evenType == ccui.ScrollviewEventType.bounceRight or evenType == ccui.ScrollviewEventType.scrollToRight
                or sender:getInnerContainerPosition().x == sender:getContentSize().width - sender:getInnerContainerSize().width then
                self.stu:getChild("node1","rightFlag"):setVisible(false)
            elseif evenType == ccui.ScrollviewEventType.bounceLeft  or evenType == ccui.ScrollviewEventType.scrollToLeft or
                sender:getInnerContainerPosition().x == 0 then
                self.stu:getChild("node1","leftFlag"):setVisible(false)
            elseif evenType == ccui.ScrollviewEventType.scrollToRight or  evenType == ccui.ScrollviewEventType.containerMoved then
                self.stu:getChild("node1","leftFlag"):setVisible(true)
                self.stu:getChild("node1","rightFlag"):setVisible(true)
            end
        end
        self.listView:addScrollViewEventListener(scrollViewEvent)
        self:updateData()
    end
    
    function __Class:setItem(item, v)
        self.index = self.index + 1
        local chengNode = UITools.getChild(item, "chengNode")
        local move = false
        local function setAdd(chengNode, i, val)
            local itemNode = chengNode:getChildByName("node_"..i)
            if not val then
                itemNode:setVisible(false)
                return
            end
            itemNode:setVisible(true)
            local user = self.proxy.jdyamen.user
            itemNode:getChildByName("nameTxt_0"):setString(val.cname)
            if val.sy == 0 then
                itemNode:getChildByName("nameTxt_0"):setTextColor(cc.c3b(255,255,255))
                itemNode:getChildByName("txt_0"):setString("已淘汰")
                itemNode:getChildByName("txt_0"):setTextColor(cc.c3b(255,0,0))
                UICommon.loadExternalTextureNormal(itemNode:getChildByName("btn"),"assetsRes/res/trade/build/2.png")
            elseif user.cid == val.cid then
                itemNode:getChildByName("nameTxt_0"):setTextColor(cc.c3b(255,0,0))
                UICommon.loadExternalTextureNormal(itemNode:getChildByName("btn"),"assetsRes/res/trade/build/3.png")
                itemNode:getChildByName("txt_0"):setString("("..val.sy.."/"..val.total..")")
                itemNode:getChildByName("txt_0"):setTextColor(cc.c3b(0,255,0))
            else
                UICommon.loadExternalTextureNormal(itemNode:getChildByName("btn"),"assetsRes/res/trade/build/4.png")
                itemNode:getChildByName("nameTxt_0"):setTextColor(cc.c3b(255,255,255))
                itemNode:getChildByName("txt_0"):setString("("..val.sy.."/"..val.total..")")
                itemNode:getChildByName("txt_0"):setTextColor(cc.c3b(0,255,0))
            end

            if user.cid == val.cid then
                itemNode:getChildByName("nameTxt_0"):setTextColor(cc.c3b(255,0,0))
            end

            if self.exist == 1 and val.sy > 0 then
                itemNode:getChildByName("shengli_0"):setVisible(true)
            else
                itemNode:getChildByName("shengli_0"):setVisible(false)
            end

            local button = itemNode:getChildByName("btn")
            button:setSwallowTouches(false) 
            button:addTouchEventListener(function (srend,eventTyp)
                -- print("sssssssssssssssssssss", v.arr[i].owner, i + ((v.id - 1) * 10))

                if eventTyp == ccui.TouchEventType.began then
                    self.indexMove = 0
                    move = false
                elseif eventTyp == ccui.TouchEventType.moved then
                    self.indexMove = self.indexMove + 1
                    if self.indexMove > 5 then 
                        move = true
                    end
                elseif eventTyp == ccui.TouchEventType.ended then
                    local state = self.proxy.jdyamen.cfg.state
                    if  move == false then
                        if state == 3 then
                            self.zero:command(GameKey.TIP,lang("grave.endhd"))
                            return
                        end
                        if self.proxy:isHaveZigeChallenge(true) then
                            return
                        end
                        if user.cid == val.cid then
                            self:command("JediYanmenCommand.showOwner",1,val)
                        else
                            self:command("JediYanmenCommand.showOwner",2,val)
                        end
                    end
                else
                    move = false
                end
            end)
        end
        for i = 1, 10 do
            setAdd(chengNode, i, v[i]) 
        end
    end

    function __Class:upView()
        
        self.listinfo = clone(self.proxy.kill20log)
        local userList = clone(self.proxy.jdyamen.userList)
        -- self.yamenProxy = self.zero:getProxy("game.yamen.YamenProxy")
        -- local listinfo = self.yamenProxy.kill20log
        local moreItem =  require("jediYanmen/jediSubItem/showLogItem")
        for i,v in ipairs(self.listinfo) do
            v.user = {}
            v.fuser = {}
            for k,j in ipairs(userList) do
                if j.u == v.uid then
                    v.user.name = j.n
                    v.user.uid = j.u
                    v.user.cid = j.c
                end
                if j.u == v.fuid then
                    v.fuser.name = j.n
                    v.fuser.uid = j.u
                    v.fuser.cid = j.c
                end
            end
        end
        -----------------列表---------------------
        local function getItem(v)
            local stu = moreItem.create()
            local item=stu.box
            item:removeSelf()
            item.setData=function (_item,v)
                self:setItem2(item,v)
            end
            return item
        end
        local TestItem = moreItem.create()
        self.ListView2:plus(TestItem.box:getContentSize(),getItem)
        self.ListView2:upList(self.listinfo)
        -----------------列表---------------------
        local isCanGetMes = true
        local function scrollViewEvent(sender, evenType)
            sender:scrollHd(evenType)
            if evenType ==  ccui.ScrollviewEventType.scrollToBottom then
                isCanGetMes = true
            elseif evenType == ccui.ScrollviewEventType.bounceBottom then
                local height = sender:getInnerContainerSize().height
                if isCanGetMes and sender:getInnerContainerPosition().y > 100 then
                    local lastLog = self.proxy.lastKillLog
                    if lastLog.id and lastLog.id > 0 then
                        -- print("ssssssssssssssss",lastLog.id)
                        self:command("JediYanmenCommand.getMoreHistory",lastLog.id,3)
                    end
                    isCanGetMes = false
                end
            end
        end
        self.ListView2:addScrollViewEventListener(scrollViewEvent)
    end
    function __Class:setItem2(item,v)
        UITools.getChild(item,"bg","rbg","rText"):setString(v.index)
        UITools.getChild(item,"bg","nameText"):setString(v.user.name)
        if self.proxy.jdyamen.user and  v.user.cid == self.proxy.jdyamen.user.cid then
            UITools.getChild(item,"bg","nameText"):setTextColor(cc.c3b(0,255,0))
        else
            UITools.getChild(item,"bg","nameText"):setTextColor(cc.c3b(255,0,0))
        end

        local noText = UITools.getChild(item,"bg","nameText","uidTxt")
        noText:setString("("..lang("rank.no",v.user.uid)..")")
        noText:setPositionX(UITools.getChild(item,"bg","nameText"):getContentSize().width+30)
        -- dump(v.user.chenghao)   
        local chenghao = UITools.getChild(item,"bg","nameText","titleImg")
        -- chenghao:ignoreContentAdaptWithSize(true)
        chenghao:setVisible(false)

        -- chenghao:setVisible(UICommon.getIsShowChengHao(v.user.chenghao))
        -- UICommon.loadExternalTexture(chenghao,UICommon.getUserTitle1IconUrl(v.user.chenghao))

        -- chenghao:setPositionX(noText:getPositionX() + noText:getContentSize().width + chenghao:getContentSize().width*0.5)    
        --衙门界面 皇帝特效
        local effect = item:getChildByTag(70)
        -- if v.user.chenghao == 22 or v.user.chenghao == 29 then 
        --     effect:setVisible(true)
        -- else
        --     effect:setVisible(false)
        -- end
        local servantProxy = self.zero:getProxy("game.servant.ServantProxy")
        local servant = servantProxy:getHeroById(v.hid)
        UITools.getChild(item,"bg","timeText"):setString(lang("mail.time")..tools.getTime(v.ktime))
        local rtes = {}
        if v.ftype == 0 and v.win == 0 then
            table.insert(rtes, UICommon.RET(lang("yamen.mt1",servant.name),26, cc.c3b(255,255,255)))
        elseif v.ftype == 0 and v.win == 1 then
            table.insert(rtes, UICommon.RET(lang("yamen.mt2",servant.name),26, cc.c3b(255,255,255)))
        elseif v.ftype == 1 and v.win == 1 then
            table.insert(rtes, UICommon.RET(lang("yamen.mt3",servant.name),26, cc.c3b(255,255,255)))
        elseif v.ftype == 1 and v.win == 0 then
            table.insert(rtes, UICommon.RET(lang("yamen.mt4",servant.name),26, cc.c3b(255,255,255)))
        end
        table.insert(rtes, UICommon.RET(v.fuser.name,26, cc.c3b(0,255,0)))
        table.insert(rtes, UICommon.RET(lang("yamen.mt5",v.kill),26, cc.c3b(255,255,255)))
        if v.dkill >= 3 then
            -- 完成了X连杀
            table.insert(rtes, UICommon.RET(lang("yamen.mt8",v.dkill),26, cc.c3b(0,255,0)))
        end

        if v.ftype == 1 then
            table.insert(rtes, UICommon.RET(lang("yamen.mt6"),26, cc.c3b(255,255,255)))
        end
        UICommon.createRichText(UITools.getChild(item,"bg","Panel"), rtes)
        if v.user.cid == self.proxy.jdyamen.user.cid then
            UITools.getChild(item,"btn"):setVisible(false)
        else
            UITools.getChild(item,"btn"):setVisible(true)
            if self.proxy:isChallenged(v.id) then
                UITools.getChild(item,"btn"):setTouchEnabled(false)
                UITools.getChild(item,"btn"):setBright(false)
                UITools.getChild(item,"btn","btnName"):enableOutline({r = 0, g = 31, b = 87, a = UICommon.toNumber("alpha1",0)}, 2)
                UITools.getChild(item,"btn","btnName"):setString(lang("yamen.challenged"))
            else
                UITools.getChild(item,"btn"):setTouchEnabled(true)
                UITools.getChild(item,"btn"):setBright(true)
                UITools.getChild(item,"btn","btnName"):enableOutline({r = 0, g = 31, b = 87, a = 255}, 2)
                UITools.getChild(item,"btn","btnName"):setString(lang("more.tiaozhan"))
                UITools.getChild(item,"btn"):addClickEventListener(function(sender)
                    if self.proxy:isHaveZigeChallenge() then
                        return
                    end
                    self:command("JediYanmenCommand.showServantView",v.user.uid,"tiaozhan",v.id)
                end)
            end
        end
    end
    function __Class:initWidget2()
        self.ListView2 = self.stu:getChild("node1","imgNode","ListView")
        self.ListView2:setBounceEnabled(true)
        -- UICommon.repeatUpAndDown(self.stu:getChild("box","jtImg"),0.8,8)
        -- self.stu:getChild("box"):moveTo({y=display.height,time = 0.15})
        self:upView()
        self:upKill()
    end

    function __Class:upKill()
        local info = self.listinfo[1]
        -- dump(info)
        if info == nil then return end
        local servantProxy = self.zero:getProxy("game.servant.ServantProxy")
        local servant = servantProxy:getHeroById(info.hid)
        local rtes = {}
        if info.ftype == 0 and info.win == 0 then
            table.insert(rtes, UICommon.RET(lang("yamen.mt1",servant.name),26, cc.c3b(255,255,255)))
        elseif info.ftype == 0 and info.win == 1 then
            table.insert(rtes, UICommon.RET(lang("yamen.mt2",servant.name),26, cc.c3b(255,255,255)))
        elseif info.ftype == 1 and info.win == 1 then
            table.insert(rtes, UICommon.RET(lang("yamen.mt3",servant.name),26, cc.c3b(255,255,255)))
        elseif info.ftype == 1 and info.win == 0 then
            table.insert(rtes, UICommon.RET(lang("yamen.mt4",servant.name),26, cc.c3b(255,255,255)))
        end
        table.insert(rtes, UICommon.RET(info.fuser.name,26, cc.c3b(0,255,0)))
        table.insert(rtes, UICommon.RET(lang("yamen.mt5",info.kill),26, cc.c3b(255,255,255)))
        if info.ftype == 1 then
            table.insert(rtes, UICommon.RET(lang("yamen.mt6"),26, cc.c3b(255,255,255)))
        end
        table.insert(rtes, UICommon.RET("...",26, cc.c3b(255,255,255)))
        -- if info.lkill >= 3 then
        --     table.insert(rtes, UICommon.RET(lang("yamen.mt7",info.lkill),24, cc.c3b(255,0,0)))
        -- end
        self.bpanel = self.stu:getChild("node1","lookMore","Panel")
        UICommon.createRichText(self.bpanel, rtes)
        self.stu:getChild("node1","lookMore","nameText"):setString(info.user.name.."("..lang("set.id",info.user.uid)..")")
    end

    function __Class:upKilllog20( ... )
        self:initWidget2()
    end
    
end
