local PanelUI=require("gameui.PanelUI")
local UITools = require("zeromvc.ui.UITools")

return function (__Class)
function __Class:using(yamenProxy)
    self.yamenProxy = yamenProxy
    self.universeProxy= self.zero:getProxy("game.universe.UniverseProxy")
    local stu=PanelUI:new("yamen.oneKeyConfirm",true)
    stu:offset(display.cx,display.cy)
    self.stu=stu
    self.canClose = false
    UICommon.openDialogAction(stu)
    local function closeHd()
        UICommon.closeDialogAction(stu,handler(self,self.hideSelf))
    end
    stu:addEvent("close",closeHd)
    local function yesHd()
        self:command("JediYanmenCommand.oneKeyPlay")
        UICommon.closeDialogAction(stu,handler(self,self.hideSelf))
    end
    stu:addEvent("yes",yesHd)

    stu:getChild("txt1"):setString(lang("yamen.Tip6"))
    stu:getChild("txt2"):setString(lang("yamen.Tip7"))
    stu:getChild("txt3"):setString(lang("yamen.Tip8"))
    return stu
end

end