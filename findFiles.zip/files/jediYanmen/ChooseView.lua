local PanelUI=require("gameui.PanelUI")
local UITools = require("zeromvc.ui.UITools")

return function (__Class)
function __Class:using(JediYanmenProxy)
    self.jediYanmenProxy = JediYanmenProxy
    self.servantProxy = self.zero:getProxy("game.servant.ServantProxy")
    self.playerProxy = self.zero:getProxy("game.player.PlayerProxy")
    self.gobalSwitchProxy = self.zero:getProxy("game.switch.GobalSwitchProxy")
    local stu=PanelUI:new("yamen.chooseView")
    stu:offset(0,display.height)
    self.stu=stu
    
    self.zero:command("game.jediYanmen.fightView")
    local function closeHd(...)
        self:hideSelf()
    end
    stu:addEvent("close",closeHd)
    stu:addEvent("attrEvent",function ()
        self.zero:show("game.jediYanmen.ShopView")
    end)
    stu:addEvent("oneKeyEvent",function ()
        self:command("JediYanmenCommand.showOneKeyConfirm")
    end)
    if self.gobalSwitchProxy:getSwitch("oneKeyYamen") then
        stu:getChild("cbg","onekey","Text"):setString(lang("yamen.oneKey"))
        stu:getChild("cbg","onekey"):setVisible(true)
        stu:getChild("cbg","onekey"):setBright(self.playerProxy.user.vip >= 6)
    else
        stu:getChild("cbg","onekey"):setVisible(false)
    end
    self:upChooseView()
    self:dealVsEffect()
    return stu
end
function __Class:upChooseView()
    local fight = self.jediYanmenProxy.fight
    local user = self.playerProxy.user
    local servant = self.servantProxy:getServantById(fight.hid)
    if servant == nil then return end
    local zz = 0
    for k,v in pairs(servant.zz) do
        zz = zz + v
    end
    self.scollView = self.stu:getChild("ScrollView")
    self.stu:getChild("hbg","nbg","nnameText"):setString(lang("yamen.fenshu",self.jediYanmenProxy:getName(fight.fuser.uid),fight.fuser.num))
    self.stu:getChild("hbg","nbg","cntText"):setString(lang("yamen.mksl",fight.fheronum-fight.killnum,fight.fheronum))
    self.stu:getChild("bbg","nbg","mnameText"):setString(lang("yamen.fenshu",self.jediYanmenProxy:getName(user.uid),self.jediYanmenProxy.jdyamen.user.score))
    self.stu:getChild("bbg","nbg","heroName"):setString(lang("yamen.dj",servant.name,servant.level))
    self.stu:getChild("bbg","nbg","zhzz","text"):setString(zz)
    self.stu:getChild("bbg","nbg","attadd","text"):setString(fight.ackadd.."%")
    self.stu:getChild("bbg","nbg","skilladd","text"):setString(fight.skilladd.."%")
    -- UICommon.loadExternalTexture(self.stu:getChild("bbg","hPanel","heroImage"),servant.fullIcon)
    UICommon.setServantImg(self.stu:getChild("bbg","hPanel","heroImage"),servant)
    self.stu:getChild("bbg","hp","LoadingBar"):setPercent(fight.hp/fight.hpmax*100)
    self.stu:getChild("bbg","hp","hpText"):setString(fight.hp.."/"..fight.hpmax)
    self:upServantList()
end

function __Class:upServantList()

    local fheros = self.jediYanmenProxy.fight.fheros
    self.scollView:removeAllChildren(false)
    for k,v in ipairs(fheros) do
        local item=require("servant/servantItem").create()
        self:setItem(item,v)
        item.box:removeSelf(false)
        self.scollView:addChild(item.box)
    end
    local itmeSize = require("servant/servantItem").create().box:getContentSize()
    tools.layoutBox(self.scollView,itmeSize.width,itmeSize.height)
  
end

function __Class:setItem(item,v)
    local servant = self.servantProxy:getHeroById(v.id)
    local function touchEventHd(sender,eventType)
        if eventType == ccui.TouchEventType.began then
            UITools.getChild(sender,"Image_1","Image_down"):setVisible(true)
        elseif eventType == ccui.TouchEventType.moved then
            UITools.getChild(sender,"Image_1","Image_down"):setVisible(false)
        elseif eventType == ccui.TouchEventType.ended then
            UITools.getChild(sender,"Image_1","Image_down"):setVisible(false)
            self:command("JediYanmenCommand.fight",v.id)
        elseif eventType == ccui.TouchEventType.canceled then
            UITools.getChild(sender,"Image_1","Image_down"):setVisible(false)
        end
    end
    item.box:addTouchEventListener(touchEventHd)
    UICommon.setServantIcon(UITools.getChild(item.box,"Image_1","mask","Image_half"),servant,{id=v.skin,dt=v.dt})
    UITools.getChild(item.box,"Image_1","txt_name"):setString("点击挑战")
    UITools.getChild(item.box,"imgRed"):setVisible(false)
    UITools.getChild(item.box,"Image_1","Image_5"):setVisible(false)
    --UICommon.repeatTintToNone(UITools.getChild(item.box,"Image_1","Image_half","Image_5"))
    if v.senior > 1 then
        UICommon.loadExternalTexture(UITools.getChild(item.box,"Image_1"),UICommon.getServantSeniorIconUrl(v.senior))
    end
end
function __Class:closeChooseView()
    self:hideSelf()
end

function __Class:dealVsEffect( ... )
    local delay = cc.DelayTime:create(0.5)
    local sequence = cc.Sequence:create(delay, cc.CallFunc:create(function( ... )
        self.stu:getChild("cbg","VSbj"):setVisible(true)
    end))
    self.stu:getChild("cbg","zhanchangVS"):runAction(sequence)
end
end