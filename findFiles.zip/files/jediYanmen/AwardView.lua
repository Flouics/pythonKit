local PanelUI=require("gameui.PanelUI")
local UITools = require("zeromvc.ui.UITools")

return function (__Class)
function __Class:using(yamenProxy)
    self.yamenProxy = yamenProxy
    self.universeProxy= self.zero:getProxy("game.universe.UniverseProxy")
    local stu=PanelUI:new("yamen.awardView",true)
    stu:offset(display.cx,display.cy)
    self.stu=stu
    self.canClose = false
    UICommon.openDialogAction(stu)
    self.stu.bg:addEvent("HIT",function(...)
        if self.canClose then
            UICommon.closeDialogAction(stu,handler(self,self.hideSelf))
            self:command("JediYanmenCommand.checkPopup")
        end
    end)
    self:initWidget()
    return stu
end

function __Class:upAwardView()
    local info = self.yamenProxy.win.rwd
    for i,v in ipairs(info.jiade) do
        local item = self.scrollView:getChildByTag(i)
        local prop = self.universeProxy:getSomeByKindAndId(v.kind,v.id)
        local back = UITools.getChild(item,"back")
        local front = UITools.getChild(item,"front")
        UICommon.loadExternalTexture(UITools.getChild(item,"front","Image_4"),prop.icon)
        UITools.getChild(item,"front","Text_1"):setString(prop.name..v.count)
        local dtime = 0
        if i ~= self.seletedid then
            dtime = 0.5
        end
        local act0 = cc.DelayTime:create(dtime)
        local act1 = cc.OrbitCamera:create(0.25, 1, 0, 0, -90, 0, 0)
        local act2 = cc.CallFunc:create(function ( ... )
            local item = self.universeProxy:getSomeByKindAndId(info.items[1].kind,info.items[1].id)
            self.stu:getChild("bbg"):setVisible(true)
            self.stu:getChild("bbg","btext"):setString(item.name.." +"..info.items[1].count)
            back:setVisible(false)
            self.canClose = true
            if i == self.seletedid then
                UICommon.repeatScale(front)
            end
        end)
        local seq1 = cc.Sequence:create(act0, cc.OrbitCamera:create(0.5, 1, 0, 0, 180, 0, 0))
        local seq2 = cc.Sequence:create(act0, act1, act2)
        front:runAction(seq1)
        back:runAction(seq2)
    end
end
function __Class:initWidget()
    self.scrollView = self.stu:getChild("bg","scrollView")
    self.bbg = self.stu:getChild("bbg")
    self.bbg:setVisible(false)
    local info = self.yamenProxy.win
    for i=1,6 do
        local item=require("yamen/awardItem").create()
        item.box:setTag(i)
        UITools.getChild(item.box,"back"):setVisible(true)
        UITools.getChild(item.box,"back"):addClickEventListener(function(sender)
            self.seletedid = i
            self:command("JediYanmenCommand.getrwd",i)
            end)
        item.box:removeSelf(false)
        self.scrollView:addChild(item.box)
    end
    local itemSize = require("yamen/awardItem").create().box:getContentSize()
    tools.layoutBox(self.scrollView ,itemSize.width,itemSize.height)
end
end