-- 个人排名
local UITools=require("zeromvc.ui.UITools")
local PanelUI=require("gameui.PanelUI")
return function (__Class)

function __Class:using(JediYanmenProxy,timeProxy)
    self.timeProxy = timeProxy
    self.jediYanmenProxy = JediYanmenProxy
    self.playerProxy =  self.zero:getProxy("game.player.PlayerProxy")
    local stu=PanelUI:new("jediYanmen.jediRankView")
    self.stu=stu
    self.listView = self.stu:getChild("listView"..self.args[1])
    self.listView:setVisible(true)
    -- self.zero:command("game.rebel.RebelCommand.CS_getRank",1)

    stu:addEvent("close",function( ... )
       self:hideSelf() 
    end)
    self.clubAllList = clone(self.jediYanmenProxy.clubAllList)
    self.stu:getChild("box1"):setVisible(false)
    self.stu:getChild("box2"):setVisible(false)
    self.stu:getChild("box3"):setVisible(false)
    self.hide = nil
    if self.args[1] == 1 then
        self:initView()
    elseif self.args[1] == 2 then
        self:initView2()
    elseif self.args[1] == 3 then
        self:initView3()
    elseif  self.args[1] == 4 then
        self:initView4()
    elseif  self.args[1] == 5 then
        self:initView5()
    end

    return stu
end

function __Class:initView( ... )
    self.stu:getChild("box1"):setVisible(true)
    self:initListView(1)
    self:initMyInfo(1)
    -- UICommon.loadExternalTexture(self.stu:getChild("bg","titleBg","title1"),"assetsRes/res/rebel/3.png")    
end

function __Class:initView2( ... )
    self.stu:getChild("box2"):setVisible(true)
    self:initListView2(2)
    self:initMyInfo2(2)
    -- UICommon.loadExternalTexture(self.stu:getChild("bg","titleBg","title1"),"assetsRes/res/rebel/3.png")    
end

function __Class:initView3( ... )
    self.stu:getChild("box3"):setVisible(true)
    self:initListView3()
    -- self:initMyInfo(3)
    -- UICommon.loadExternalTexture(self.stu:getChild("bg","titleBg","title1"),"assetsRes/res/rebel/3.png")    
end

function __Class:initView4( ... )
    self.stu:getChild("box4"):setVisible(true)
    self:initListView4(4)
    self:initClubInfo(4)
    -- UICommon.loadExternalTexture(self.stu:getChild("bg","titleBg","title1"),"assetsRes/res/rebel/3.png")    
end

function __Class:initView5( ... )
    self.stu:getChild("box5"):setVisible(true)
    self:initListView5(5)
    self:initMyInfo5(5)
    self.activityProxy = self.zero:getProxy("game.activity.ActivityProxy")
    local eTime = 0
    if self.activityProxy.openActivities[62] and self.activityProxy.openActivities[62][319] then
        eTime = self.activityProxy.openActivities[62][319].yueTime - 7200
    end
    self.upTime_jdyamen = function ( ... )
        local servarTime = self.timeProxy:getTime()
        local next1 = eTime
        local nowTime = next1 - servarTime 
        local h = lang("time",nowTime < 0 and 0 or nowTime)

        if nowTime <= 0 then
            self.stu:getChild("box5","myInfo","time"):setString(lang("juediyamen.yuxuansaiOver"))
        else
            self.stu:getChild("box5","myInfo","time"):setString(lang("juediyamen.jiesuandaojishi")..h)
        end
        -- local num = self.jediYanmenProxy:setHour(servarTime)
        if servarTime >=  eTime +  7200 then
            if not self.stopOpen then
                self.stopOpen = true
                self:command("JediYanmenCommand.showJediYamen")
            end
            self.stu:getChild("box5","myInfo","time"):setString(lang("juediyamen.yuxuansaiOver"))
        end
    end
    self.upTime_jdyamen()
    -- UICommon.loadExternalTexture(self.stu:getChild("bg","titleBg","title1"),"assetsRes/res/rebel/3.png")    
end

-- 活动商城
function __Class:initListView( type )

    local dielist = clone(self.jediYanmenProxy.jdyamen.dielist)
    local scorelist = clone(self.jediYanmenProxy.jdyamen.scorelist)
    self.liveLen = #self.jediYanmenProxy.jdyamen.scorelist
    table.insertto(scorelist,dielist)
    self.lunshu = self.jediYanmenProxy.jdyamen.cfg.lun
    if self.lunshu and self.lunshu ~=0 then
        self.paiming =  self.jediYanmenProxy.jdyamen.cfg.lunshu[self.lunshu].num
    else
        self.paiming = 2
    end
    self.dataArr =  scorelist
    table.sort(self.dataArr,function ( a,b )
        return a.rid < b.rid 
    end)
    -- 
    local itemName = "jediYanmen/jediSubItem/rankItem"
    local function getItem(v)
        local stu = require(itemName).create()
        local item=stu.box
        item:removeSelf()
        item.setData=function (_item,v)
            self:setItem(item,v)
        end
        return item
    end
    local TestItem = require(itemName).create()
    self.listView:plus(TestItem.box:getContentSize(),getItem)
    self.listView:upList(self.dataArr)
end

function __Class:setItem( item,v )
    local bg = UITools.getChild(item,"bg")
    local rankText = UITools.getChild(item,"rankText")
    local rankImg = UITools.getChild(item,"rankImage")
    local nameText = UITools.getChild(item,"nameText")
    local score = UITools.getChild(item,"infoText")
    local clubName = UITools.getChild(item,"clubName")
    rankImg:setVisible((v.rid < 4))

    rankText:setString(v.rid)

    bg:setVisible((v.rid%2) == 1)

    for i=1,3 do
       local rankImg = UITools.getChild(item,"rankImage","img"..i)
       rankImg:setVisible((v.rid == i))
    end

    local club = self.jediYanmenProxy:getClub(v.cid)
    local user = self.jediYanmenProxy:getMember(club,v.uid)
    if not user then
        nameText:setString("")
        score:setString(v.score)
        clubName:setString(club.cname)
        return
    end

    nameText:setString(user.n)
    score:setString(v.score)
    clubName:setString(club.cname)


    local color = self.jediYanmenProxy:getClolor(v.uid,v.rid,self.clubInfo,self.liveLen,v.rid) 
    nameText:setTextColor(color)
    score:setTextColor(color)
    clubName:setTextColor(color)
    rankText:setTextColor(color)
end

-- 活动商城
function __Class:initListView2( type )

    self.dataArr = clone(self.jediYanmenProxy.jdyamen.clubRankList)
    -- dump(self.dataArr)
    -- 
    table.sort(self.dataArr ,function ( a,b )
        return a.rid < b.rid
    end)

    local itemName = "jediYanmen/jediSubItem/rankItem"
    local function getItem(v)
        local stu = require(itemName).create()
        local item=stu.box
        item:removeSelf()
        item.setData=function (_item,v)
            self:setItem2(item,v)
        end
        return item
    end
    local TestItem = require(itemName).create()
    self.listView:plus(TestItem.box:getContentSize(),getItem)
    self.listView:upList(self.dataArr)
end

function __Class:setItem2( item,v )
    local bg = UITools.getChild(item,"bg")
    local rankText = UITools.getChild(item,"rankText")
    local rankImg = UITools.getChild(item,"rankImage")
    local nameText = UITools.getChild(item,"nameText")
    local score = UITools.getChild(item,"infoText")
    local clubName = UITools.getChild(item,"clubName")
    rankImg:setVisible(false)

    rankText:setString(v.rid)

    bg:setVisible((v.rid%2) == 1)

    for i=1,3 do
       local rankImg = UITools.getChild(item,"rankImage","img"..i)
       rankImg:setVisible((v.rid == i))
    end

    local club = self.jediYanmenProxy:getClub(v.cid)

    nameText:setString(club.cname)
    clubName:setString(club.sy)
    score:setString(v.score)
    if club.sy == 0 then
        nameText:setTextColor(cc.c3b(255,0,0))
        score:setTextColor(cc.c3b(255,0,0))
        clubName:setTextColor(cc.c3b(255,0,0))
        rankText:setTextColor(cc.c3b(255,0,0))
    else
        nameText:setTextColor(cc.c3b(0,255,0))
        score:setTextColor(cc.c3b(0,255,0))
        clubName:setTextColor(cc.c3b(0,255,0))
        rankText:setTextColor(cc.c3b(0,255,0))
    end
end

function __Class:initListView3( )
  
    self.dataArr = clone(self.jediYanmenProxy.jdyamen.cfg.lunshu)
    -- dump(self.dataArr)
    -- 
    local itemName = "rebel/itemRank"
    local function getItem(v)
        local stu = require(itemName).create()
        local item=stu.box
        item:removeSelf()
        item.setData=function (_item,v)
            self:setItem3(item,v)
        end
        return item
    end
    local TestItem = require(itemName).create()
    self.listView:plus(TestItem.box:getContentSize(),getItem)
    self.listView:upList(self.dataArr)
end

function __Class:setItem3( item,v )
    local bg = UITools.getChild(item,"bg")
    local rankText = UITools.getChild(item,"rankText")
    local rankImg = UITools.getChild(item,"rankImage")
    rankImg:setVisible((v.id < 4))

    rankText:setString(v.id)

    bg:setVisible((v.id%2) == 1)

    for i=1,3 do
       local rankImg = UITools.getChild(item,"rankImage","img"..i)
       rankImg:setVisible((v.id == i))
    end

    local nameText = UITools.getChild(item,"nameText")
    nameText:setString(os.date("%m"..lang("mail.month").."%d"..lang("juediyamen.number").." %H:%M:%S",v.time))

    local score = UITools.getChild(item,"infoText")
    score:setString(v.msg)
end

function __Class:initListView4( )

    self.club = self.args[2]
    self.clubInfo = clone(self.jediYanmenProxy.jdyamen.clubInfo)
    dump(self.clubInfo,"数据------------")
    for i,v in ipairs(self.clubInfo) do
        self.qufu = self.playerProxy:getArea(v.u.uid)
        break
    end

    table.sort(self.clubInfo,function ( a,b )
        return a.rid < b.rid
    end)

    local index = 1
    for k,v in ipairs(self.clubInfo) do
        v.id = index 
        index= index + 1
        for i,val in ipairs(self.jediYanmenProxy.jdyamen.userList) do
            if val.u == v.u.uid then
                v.u.name = val.n
                break
            end
        end
    end
    -- 
    local itemName = "rebel/itemRank"
    local function getItem(v)
        local stu = require(itemName).create()
        local item=stu.box
        item:removeSelf()
        item.setData=function (_item,v)
            self:setItem4(item,v)
        end
        return item
    end
    local TestItem = require(itemName).create()
    self.listView:plus(TestItem.box:getContentSize(),getItem)
    self.listView:upList(self.clubInfo)
end

function __Class:setItem4( item,v )
    local bg = UITools.getChild(item,"bg")
    local rankText = UITools.getChild(item,"rankText")
    local rankImg = UITools.getChild(item,"rankImage")

    rankImg:setVisible(false)

    rankText:setString(v.rid)

    bg:setVisible((v.id%2) == 1)


    local nameText = UITools.getChild(item,"nameText")
    nameText:setString(v.u.name)

    local score = UITools.getChild(item,"infoText")
    score:setString(v.score)

    local color = self.jediYanmenProxy:getClolor(v.u.uid,v.rid,"",self.club.sy,v.id) 
    rankText:setTextColor(color)
    nameText:setTextColor(color)
    score:setTextColor(color)

end

function __Class:initListView5( )
  
    self.data = clone(self.jediYanmenProxy.jdyamen.yuxuan)
    if not self.data then
        self.data = {}
        return
    end
    -- dump(self.data)
    local index = 1
    for i,v in ipairs(self.data) do
        v.id = index 
        index= index + 1
    end
    -- 
    local itemName = "rebel/itemRank"
    local function getItem(v)
        local stu = require(itemName).create()
        local item=stu.box
        item:removeSelf()
        item.setData=function (_item,v)
            self:setItem5(item,v)
        end
        return item
    end
    local TestItem = require(itemName).create()
    self.listView:plus(TestItem.box:getContentSize(),getItem)
    self.listView:upList(self.data.list)
end

function __Class:setItem5( item,v )
    -- dump(v)
    local bg = UITools.getChild(item,"bg")
    local rankText = UITools.getChild(item,"rankText")
    local rankImg = UITools.getChild(item,"rankImage")
    rankImg:setVisible((v.rid < 4))

    rankText:setString(v.rid)

    bg:setVisible((v.rid%2) == 1)

    for i=1,3 do
       local rankImg = UITools.getChild(item,"rankImage","img"..i)
       rankImg:setVisible((v.rid == i))
    end

    local nameText = UITools.getChild(item,"nameText")
    nameText:setString(v.name)

    local score = UITools.getChild(item,"infoText")
    score:setString(v.score)
end

function __Class:initMyInfo( i)
    local myRankInfo = self.jediYanmenProxy.jdyamen.user
    local club = self.clubAllList[myRankInfo.cid]
    local name = self.stu:getChild("box"..i,"myInfo")
    local rank = self.stu:getChild("box"..i,"myInfo","rank")
    local score = self.stu:getChild("box"..i,"myInfo","zhangfu")
    local clubs = self.stu:getChild("box"..i,"myInfo","club")
    -- dump(club,"")
    -- dump(myRankInfo)
    if not club then
        name:setString(lang("boss.name1")..lang("champion.nojoin"))
        rank:setString(lang("rank.paiming2")..lang("champion.nojoin"))
        score:setString(lang("rebel.score",lang("champion.nojoin")))
        clubs:setString(lang("union.bh").." "..lang("champion.nojoin"))
        return
    end
    local userInfo = club.member[self.playerProxy.user.uid]
    
    if myRankInfo and userInfo  then
        if i == 1 then
            clubs:setString(lang("union.bh").." "..club.cname)
        end
        name:setString(lang("boss.name1")..userInfo.n)
        rank:setString(lang("rank.paiming2")..myRankInfo.rid)
        score:setString(lang("rebel.score",myRankInfo.score))
    else
        name:setString(lang("boss.name1")..lang("champion.nojoin"))
        rank:setString(lang("rank.paiming2")..lang("champion.nojoin"))
        score:setString(lang("rebel.score",lang("champion.nojoin")))
    end
end

function __Class:initMyInfo2( i)
    local name = self.stu:getChild("box"..i,"myInfo")
    local rank = self.stu:getChild("box"..i,"myInfo","rank")
    local score = self.stu:getChild("box"..i,"myInfo","zhangfu")
    local myRankInfo = self.jediYanmenProxy.jdyamen.user
    local club = self.clubAllList[myRankInfo.cid]
    if not club then
        name:setString(lang("union.bh").." "..lang("champion.nojoin"))
        rank:setString(lang("rank.paiming2")..lang("champion.nojoin"))
        score:setString(lang("rebel.score",lang("champion.nojoin")))
        return
    end
    for i,v in ipairs(self.dataArr) do
        if tonumber(club.cid) == tonumber(v.cid) then
            club.score = v.score
        end
    end
    -- dump(club,"")
    -- dump(myRankInfo)
    -- local userInfo = club.member[self.playerProxy.user.uid]
    
    if myRankInfo  then
        name:setString(lang("union.bh")..club.cname)
        rank:setString(lang("rank.paiming2")..tonumber(self.jediYanmenProxy:getClubRank()))
        score:setString(lang("rebel.score",tonumber(self.jediYanmenProxy:getClubScore())))    
    end
end

function __Class:initMyInfo5( i)
    local myData = self.data.my
    -- dump(myData,"")
    -- local userInfo = club.member[self.playerProxy.user.uid]
    local name = self.stu:getChild("box"..i,"myInfo")
    local rank = self.stu:getChild("box"..i,"myInfo","rank")
    local score = self.stu:getChild("box"..i,"myInfo","zhangfu")
    local num = self.stu:getChild("box"..i,"num")
    
    if myData  then
        name:setString(lang("union.bh")..myData.name)
        rank:setString(lang("rank.paiming2")..myData.rid)
        score:setString(lang("rebel.score",myData.score))
        num:setString(self.data.num)
    else
        name:setString(lang("union.bh")..lang("champion.nojoin"))
        rank:setString(lang("rank.paiming2")..lang("champion.nojoin"))
        score:setString(lang("rebel.score",lang("champion.nojoin")))
    end
end

function __Class:initClubInfo( i )
    local myRankInfo = self.club
    local name = self.stu:getChild("box"..i,"myInfo")
    local rank = self.stu:getChild("box"..i,"myInfo","rank")
    local score = self.stu:getChild("box"..i,"myInfo","zhangfu")
    local challenge = self.stu:getChild("box"..i,"myInfo","challenge")
    
    if myRankInfo  then
        name:setString(lang("juediyamen.lianmeng")..myRankInfo.cname)
        rank:setString(lang("union.war.quFuTitle").."："..self.qufu)
        score:setString(myRankInfo.sy.."/"..myRankInfo.total)
    else
        name:setString(lang("juediyamen.lianmeng")..lang("champion.nojoin"))
        rank:setString(lang("union.war.quFuTitle").."："..lang("champion.nojoin"))
        score:setString(lang("champion.nojoin"))
    end

    if self.args[2].sy == 0 then
        challenge:setVisible(false)
    end
    challenge:addClickEventListener(function ( ... )
        if self.jediYanmenProxy:isHaveZigeChallenge(false) then
            return
        end
        self.zero:show("game.jediYanmen.JediChallenge",self.args[2])
    end)
end

function __Class:closejediRank( ... )
    self:hideSelf()
end

end