local PanelUI=require("gameui.PanelUI")
local UITools = require("zeromvc.ui.UITools")

return function (__Class)
function __Class:using(yamenProxy)
    self.yamenProxy = yamenProxy
    self.bagProxy = self.zero:getProxy("game.bag.BagProxy")
    self.servantProxy = self.zero:getProxy("game.servant.ServantProxy")
    self.uid = self.args[1]
    self.type = self.args[2]
    self.logId = self.args[3]
    self.time = self.args[4]
    local stu=PanelUI:new("yamen.servantView",true)
    stu:offset(display.cx,display.cy)
    self.stu=stu
    UICommon.openDialogAction(stu)
    local function closeHd()
        UICommon.closeDialogAction(stu,handler(self,self.hideSelf))
    end
    self.stu:getChild("infoText"):setVisible(false)
    stu:addEvent("close",closeHd)
    self:initWidget()
    return stu
end

function __Class:initWidget()
    local servant = {}
    local fclist = self.yamenProxy.fclist
    for k,v in pairs(self.servantProxy:getUnexileServantList()) do
        -- 门客大于60级并且还活着
        if  ( not (fclist[v.id] ~= nil and fclist[v.id].h == 0)) then
            table.insert(servant,v)
        end
    end
    table.sort(servant,function (a,b)
        return a.totalEp > b.totalEp
    end)
    
    local listView = self.stu:getChild("gBack","ListView")
    listView:setBounceEnabled(true)
    for i,v in ipairs(servant) do
        local item = require("yamen/servantItem").create()
        self:setItem(item.box,v)
        item.box:removeSelf(false)
        listView:pushBackCustomItem(item.box)
    end

    local item
    if self.type == "tiaozhan" then
        item = self.bagProxy:getThingById(125)
    elseif self.type == "zhuisha" then
        item = self.bagProxy:getThingById(131)
        -- self.stu:getChild("infoText"):setString(lang("yamen.zsdx")..self.yamenProxy.zhuisha.fuser.name)
        UICommon.loadExternalTexture(self.stu:getChild("gBack","imgTitlebg","titleImg"),"assetsRes/res/headline/headline146.png")
    elseif self.type == "fuchou" then
        item = self.bagProxy:getThingById(125)
    end
    self.stu:getChild("cntText"):setString(item.name..":"..item.count)
end

function __Class:setItem(item,v)
    UITools.getChild(item,"bg","nameText"):setString(v.name)
    UITools.getChild(item,"bg","levelText"):setString(v.level)
    UITools.getChild(item,"bg","zzText"):setString(v.rTotalZz)
    UITools.getChild(item,"bg","sxText"):setString(v.totalEp)
    if v.senior > 1 then
        UICommon.loadExternalTexture(UITools.getChild(item,"fbg"),UICommon.getServantSeniorIconUrl(v.senior))
    end
    UICommon.setServantIcon(UITools.getChild(item,"fbg","face"),v)
    UITools.getChild(item,"btn","btnName"):setString(lang("yamen."..self.type))
    UITools.getChild(item,"btn"):addClickEventListener(function(sender)
        self:command("JediYanmenCommand."..self.type,v.id,self.uid,self.logId,self.time,function ( ... )
            self:hideSelf()
            self.zero:hide("game.jediYanmen.JediChallenge")
            self.zero:hide("game.jediYanmen.jediRankView")
        end)
    end)
end
function __Class:closeServantView()
    UICommon.closeDialogAction(self.stu,handler(self,self.hideSelf))
end
end