local PanelUI = require("gameui.PanelUI")
local UITools = require("zeromvc.ui.UITools")
local TabFM = require "gameui.TabFM"
return function (__Class)
    function __Class:using(yamenProxy)
        self.yamenProxy = yamenProxy
        self.playerProxy = self.zero:getProxy("game.player.PlayerProxy")
        self.servantProxy = self.zero:getProxy("game.servant.ServantProxy")
        self.activityProxy = self.zero:getProxy("game.activity.ActivityProxy")
        local stu = PanelUI:new("jediYanmen.jediVisitView", true)
        stu:offset(display.cx, display.cy)
        self.stu = stu
        
        self.type = self.args[1]
        if self.type == nil then
            self.type = 1
        end
        self.isCanZhuiSha = false

        self.isPushDown = true
        self.lastSerchId = 0
        self.recordInfo = {}
        self.isChange=true

        UICommon.openDialogAction(stu)
        local function closeHd(...)
            UICommon.closeDialogAction(stu, handler(self, self.hideSelf))
        end
        stu:addEvent("close", closeHd)
        UICommon.createEditBox(self.stu:getChild("gBack", "box3", "Image_8", "Image_7"), nil, cc.c3b(255, 255, 255), lang("find.textfield"), 26, 10)
        local function editBoxTextEventHandle(strEventName,pSender)
            local edit = pSender
            local strFmt = ""
            if strEventName == "began" then
                self:showRecordList(true)
            elseif strEventName == "ended" then
            elseif strEventName == "return" then
                
            elseif strEventName == "changed" then
                
            end
        end
        self.stu:getChild("gBack","box3","Image_8","Image_7"):getChildByName("editMes"):registerScriptEditBoxHandler(editBoxTextEventHandle)
        stu:addEvent("findEvent", function ()
            self:showRecordList(true)
            self:serch()
        end)
        stu:addEvent("chase", function ()
            if self.isCanZhuiSha then
                self:command("JediYanmenCommand.showServantView", self.yamenProxy.zhuisha.fuser.id, "zhuisha", 0)
            else
                self.zero:command(GameKey.TIP, lang("yamen.nouid"))
            end
        end)
        local function pushDownHd(stu,event,sender,clickType)
            local length=#self.recordInfo
            if length ~=0 then
                self:showRecordList()
            end
        end
        stu:addEvent("pushDownEvent",pushDownHd)
        self.recordInfo=self.yamenProxy:getJDRecords(self.playerProxy.user.uid)
        local etime=self.activityProxy.openActivities[62][319].eTime
        if etime ~= self.yamenProxy.serchJDRecordData.time  then
            self.recordInfo={}
            self.yamenProxy.serchJDRecordData.list={}
            self.yamenProxy.serchJDRecordData.time=etime
        end
        self:initWidget()
        self:upBox1()
        self:upBox2()
        
        local switchProxy = self.zero:getProxy("game.switch.GobalSwitchProxy")
        if switchProxy:getSwitch("isHideForCheck") then
            stu:getChild("gBack", "btn3", "Text"):setString(lang("check.check2"))
            stu:getChild("gBack", "box3", "txtBottomTip"):setString(lang("check.check2"))
            stu:getChild("gBack", "box3", "Text_76"):setString(lang("check.check3", lang("check.check2")))
            -- UICommon.loadExternalTexture(stu:getChild("gBack","box3","Image_8"),"assetsRes/res/hint/hint140_1.png")
        else
            stu:getChild("gBack", "btn3", "Text"):setString(lang("check.check1"))
            stu:getChild("gBack", "box3", "txtBottomTip"):setString(lang("check.check1"))
            stu:getChild("gBack", "box3", "Text_76"):setString(lang("check.check3", lang("check.check1")))
            -- UICommon.loadExternalTexture(stu:getChild("gBack","box3","Image_8"),"assetsRes/res/hint/hint140.png")
        end
        
        return stu
    end
    
    function __Class:serch()
        local str=self.stu:getChild("gBack","box3","Image_8","Image_7"):getChildByName("editMes"):getText()
        if tostring(self.lastSerchId) ~= str then
            self:command("JediYanmenCommand.find",str)
        end
    end

    function __Class:initWidget()
        -- local bg = self.stu:getChild("gBack","bbg")
        local bgtext = self.stu:getChild("gBack", "Text")
        self.node3 = self.stu:getChild("gBack", "box3", "node3")
        self.rolePanel = self.stu:getChild("gBack", "box3", "node3", "cutPanel", "rolePanel")
        self.txtName = self.stu:getChild("gBack", "box3", "node3", "txtName")
        self.slval = self.stu:getChild("gBack", "box3", "node3", "slval")
        self.mkval = self.stu:getChild("gBack", "box3", "node3", "mkval")
        self.fsval = self.stu:getChild("gBack", "box3", "node3", "fsval")
        self.phval = self.stu:getChild("gBack", "box3", "node3", "phval")
        self.pushDown = self.stu:getChild("gBack","box3","pushDown")
        self.pushV = self.stu:getChild("gBack","box3","pushV")
        self.listView1 = self.stu:getChild("gBack", "box1", "listView")
        self.listView2 = self.stu:getChild("gBack", "box2", "listView")
        self.listView1:setBounceEnabled(true)
        self.listView2:setBounceEnabled(true)
        self.node3:setVisible(false)
        local tab = TabFM:new()
        tab:addBtn(self.stu:getChild("gBack", "btn1"), self.stu:getChild("gBack", "box1"))
        tab:addBtn(self.stu:getChild("gBack", "btn2"), self.stu:getChild("gBack", "box2"))
        tab:addBtn(self.stu:getChild("gBack", "btn3"), self.stu:getChild("gBack", "box3"))
        tab:addEvent("cut", function (sender, type, id)
            -- if id ==1 then
            --     bg:setVisible(true)
            -- elseif id==2 then
            --     bg:setVisible(true)
            -- elseif id==3 then
            --     bg:setVisible(false)
            -- end
        end)
        tab:cut(self.type)
    end
    
    function __Class:upBox1()
        local info = clone(self.yamenProxy.deflog)
        local userList = clone(self.yamenProxy.jdyamen.userList)
        for i, v in ipairs(info) do
            v.user = {}
            v.fuser = {}
            for k, j in ipairs(userList) do
                if j.u == v.uid then
                    v.user.name = j.n
                    v.user.uid = j.u
                    v.user.cid = j.c
                end
                if j.u == v.fuid then
                    v.fuser.name = j.n
                    v.fuser.uid = j.u
                    v.fuser.cid = j.c
                end
            end
        end
        -- dump(info)
        local moreItem = require("jediYanmen/jediSubItem/showLogItem")
        self.stu:getChild("gBack", "box1", "Text"):setVisible(#info <= 0)
        local function getItem(v)
            local stu = moreItem.create()
            local item = stu.box
            item:removeSelf()
            item.setData = function (_item, v)
                self:setItem1(item, v)
            end
            return item
        end
        local TestItem = moreItem.create()
        self.listView1:plus(TestItem.box:getContentSize(), getItem)
        self.listView1:upList(info)
        
        local isCanGetMes = true
        local function scrollViewEvent(sender, evenType)
            sender:scrollHd(evenType)
            if evenType == ccui.ScrollviewEventType.scrollToBottom then
                isCanGetMes = true
            elseif evenType == ccui.ScrollviewEventType.bounceBottom then
                local height = sender:getInnerContainerSize().height
                if isCanGetMes and sender:getInnerContainerPosition().y > 100 then
                    local lastLog = self.yamenProxy.lastDeflog
                    if lastLog.id and lastLog.id > 0 then
                        self:command("JediYanmenCommand.getMoreHistory", lastLog.id, 3)
                    end
                    isCanGetMes = false
                end
            end
        end
        self.listView1:addScrollViewEventListener(scrollViewEvent)
        ---------------------
        
    end
    function __Class:setItem1(item, v)
        UITools.getChild(item, "bg", "rbg", "rText"):setString(v.index)
        UITools.getChild(item, "bg", "nameText"):setString(v.user.name)
        
        local noText = UITools.getChild(item, "bg", "nameText", "uidTxt")
        noText:setString("("..lang("rank.no", v.user.uid) .. ")")
        noText:setPositionX(UITools.getChild(item, "bg", "nameText"):getContentSize().width + 30)
        -- dump(v.user.chenghao)
        local chenghao = UITools.getChild(item, "bg", "nameText", "titleImg")
        -- chenghao:ignoreContentAdaptWithSize(true)
        chenghao:setVisible(false)
        
        -- chenghao:setVisible(UICommon.getIsShowChengHao(v.user.chenghao))
        -- UICommon.loadExternalTexture(chenghao,UICommon.getUserTitle1IconUrl(v.user.chenghao))
        
        -- chenghao:setPositionX(noText:getPositionX() + noText:getContentSize().width + chenghao:getContentSize().width*0.5)
        --衙门界面 皇帝特效
        local effect = item:getChildByTag(70)
        -- if v.user.chenghao == 22 or v.user.chenghao == 29 then
        --     effect:setVisible(true)
        -- else
        --     effect:setVisible(false)
        -- end
        local servantProxy = self.zero:getProxy("game.servant.ServantProxy")
        local servant = servantProxy:getHeroById(v.hid)
        
        local s, color
        if v.mscore == 0 then
            s = "+"..v.mscore
            color = cc.c3b(0, 255, 0)
        else
            s = v.mscore
            color = cc.c3b(255, 0, 0)
        end
        UITools.getChild(item, "bg", "timeText"):setString(lang("yamen.dzxx")..s)
        UITools.getChild(item, "bg", "timeText2"):setString(lang("dateDiff", v.dtime))
        UITools.getChild(item, "bg", "timeText2"):setVisible(true)
        UITools.getChild(item, "bg", "timeText"):setTextColor(color)
        local rtes = {}
        
        table.insert(rtes, UICommon.RET(lang("juediyamen.mt4", servant.name), 26, cc.c3b(255, 255, 255)))
        if v.win  > 0 then
            table.insert(rtes, UICommon.RET(lang("juediyamen.quanjian"), 26, cc.c3b(255, 255, 255)))
        else
            table.insert(rtes, UICommon.RET(lang("juediyamen.zhansheng"), 26, cc.c3b(255, 255, 255)))
        end
        table.insert(rtes, UICommon.RET("  "..v.fuser.name.."  ", 26, cc.c3b(255, 255, 255)))
        table.insert(rtes, UICommon.RET(lang("yamen.mt5", v.kill), 26, cc.c3b(255, 255, 255)))
        if v.dkill then
            if v.dkill >= 3 then
                -- 完成了X连杀
                table.insert(rtes, UICommon.RET(lang("yamen.mt8", v.dkill), 26, cc.c3b(0, 255, 0)))
            end
        end
        
        if v.ftype == 1 then
            table.insert(rtes, UICommon.RET(lang("yamen.mt6"), 26, cc.c3b(255, 255, 255)))
        end
        UICommon.createRichText(UITools.getChild(item, "bg", "Panel"), rtes)
        if v.user.uid == self.playerProxy.user.uid then
            UITools.getChild(item, "btn"):setVisible(false)
        else
            UITools.getChild(item, "btn"):setVisible(true)
            if self.yamenProxy:isChallenged(v.id) then
                UITools.getChild(item, "btn"):setTouchEnabled(false)
                UITools.getChild(item, "btn"):setBright(false)
                UITools.getChild(item, "btn", "btnName"):enableOutline({r = 0, g = 31, b = 87, a = UICommon.toNumber("alpha1", 0)}, 2)
                UITools.getChild(item, "btn", "btnName"):setString(lang("yamen.challenged"))
            else
                UITools.getChild(item, "btn"):setTouchEnabled(true)
                UITools.getChild(item, "btn"):setBright(true)
                UITools.getChild(item, "btn", "btnName"):enableOutline({r = 0, g = 31, b = 87, a = 255}, 2)
                UITools.getChild(item, "btn", "btnName"):setString(lang("more.tiaozhan"))
                UITools.getChild(item, "btn"):addClickEventListener(function(sender)
                    if self.yamenProxy:isHaveZigeChallenge() then
                        return
                    end
                    self:command("JediYanmenCommand.showServantView", v.user.uid, "tiaozhan", v.id)
                end)
            end
        end
        UITools.getChild(item, "btn"):setVisible(false)
    end
    
    function __Class:upBox2()
        local info = self.yamenProxy.enymsg
        local userList = clone(self.yamenProxy.jdyamen.userList)
        for i, v in ipairs(info) do
            v.user = {}
            v.fuser = {}
            for k, j in ipairs(userList) do
                if j.u == v.uid then
                    v.fuser.name = j.n
                    v.fuser.uid = j.u
                    v.fuser.cid = j.c
                end
            end
        end
        -- dump(info)
        self.stu:getChild("gBack", "box2", "Text"):setVisible(#info <= 0)
        local moreItem = require("jediYanmen/jediSubItem/enemyItem")
        local function getItem(v)
            local stu = moreItem.create()
            local item = stu.box
            item:removeSelf()
            item.setData = function (_item, v)
                self:setItem2(item, v)
            end
            return item
        end
        local TestItem = moreItem.create()
        self.listView2:plus(TestItem.box:getContentSize(), getItem)
        self.listView2:upList(info)
        
        local isCanGetMes = true
        local function scrollViewEvent(sender, evenType)
            sender:scrollHd(evenType)
            if evenType == ccui.ScrollviewEventType.scrollToBottom then
                isCanGetMes = true
            elseif evenType == ccui.ScrollviewEventType.bounceBottom then
                local height = sender:getInnerContainerSize().height
                if isCanGetMes and sender:getInnerContainerPosition().y > 100 then
                    local lastLog = self.yamenProxy.lastEnymsg
                    if lastLog.id and lastLog.id > 0 then
                        self:command("JediYanmenCommand.getMoreHistory", lastLog.id, 3)
                    end
                    isCanGetMes = false
                end
            end
        end
        self.listView2:addScrollViewEventListener(scrollViewEvent)
    end
    function __Class:setItem2(item, v)
        UITools.getChild(item, "bg", "rbg", "rText"):setString(v.index)
        UITools.getChild(item, "bg", "nameText"):setString(v.fuser.name)
        
        local noText = UITools.getChild(item, "bg", "nameText", "uidTxt")
        noText:setString("("..lang("rank.no", v.fuser.uid) .. ")")
        noText:setPositionX(UITools.getChild(item, "bg", "nameText"):getContentSize().width + 30)
        -- dump(v.user.chenghao)
        local chenghao = UITools.getChild(item, "bg", "nameText", "titleImg")
        chenghao:setVisible(false)

        --衙门界面 皇帝特效
        local effect = item:getChildByTag(70)

        local servantProxy = self.zero:getProxy("game.servant.ServantProxy")
        local servant = servantProxy:getHeroById(v.hid)
        
        UITools.getChild(item, "bg", "timeText"):setString(v.score)
        UITools.getChild(item, "bg", "timeText2"):setString(lang("dateDiff", v.time))
        UITools.getChild(item, "bg", "timeText2"):setVisible(true)
        if self.yamenProxy.clubAllList[v.cid] then
            UITools.getChild(item, "bg", "banghui"):setString(lang("rank.bhText",self.yamenProxy.clubAllList[v.cid].cname)) 
        end

        if v.fuser.uid == self.playerProxy.user.uid then
            UITools.getChild(item, "btn"):setVisible(false)
        else
            UITools.getChild(item, "btn"):setVisible(true)
            if self.yamenProxy:isChallenged(v.id) then
                UITools.getChild(item, "btn"):setTouchEnabled(false)
                UITools.getChild(item, "btn"):setBright(false)
                UITools.getChild(item, "btn", "btnName"):enableOutline({r = 126, g = 78, b = 24, a = UICommon.toNumber("alpha1", 0)}, 2)
                UITools.getChild(item, "btn", "btnName"):setString(lang("juediyamen.fuchou"))
            else
                UITools.getChild(item, "btn"):setTouchEnabled(true)
                UITools.getChild(item, "btn"):setBright(true)
                UITools.getChild(item, "btn", "btnName"):enableOutline({r = 126, g = 78, b = 24, a = 255}, 2)
                UITools.getChild(item, "btn", "btnName"):setString(lang("juediyamen.fuchou"))
                UITools.getChild(item, "btn"):addClickEventListener(function(sender)
                    if self.yamenProxy:isHaveZigeChallenge() then
                        return
                    end
                    self:command("JediYanmenCommand.showServantView", v.fuser.uid, "fuchou",0, v.time)
                end)
            end
        end
    end
    function __Class:upBox3()
        self.isCanZhuiSha = true
        local zhuisha = self.yamenProxy.zhuisha
        local user = zhuisha.fuser

        self.lastSerchId=user.id
        local isS=self:isSaved(user.id)
        if isS then
            table.remove(self.recordInfo,isS)
        end
        local record={name="",id=0}
        record.name=user.name
        record.id=user.id
        table.insert(self.recordInfo,1,record)
        self.yamenProxy.serchJDRecordData.list[self.playerProxy.user.uid] = self.recordInfo
        cc.UserDefault:getInstance():setStringForKey("yamenRecordJD",json.encode(self.yamenProxy.serchJDRecordData))
        self.isChange=true

        self.node3:setVisible(true)
        self.txtName:setString(self.yamenProxy:getName(user.id))
        self.slval:setString(user.shili)
        self.mkval:setString(zhuisha.hnum)
        self.fsval:setString(zhuisha.score)
        self.phval:setString(zhuisha.rank)
        local size = self.rolePanel:getContentSize()
        local img = UICommon.getRoleImg(user)
        -- ！！！同步时请注意！！官服2.0版本代码！不是这个版本注意修改代码！！！
        img:setPosition(size.width + (img:getContentSize().width - size.width) / 2, size.height + (img:getContentSize().height - size.height) / 2 - 30)
        --img:setPosition(size.width,size.height)
        self.rolePanel:removeAllChildren()
        self.rolePanel:addChild(img)
        
    end
    function __Class:isSaved(fuid)
        for k,v in pairs(self.recordInfo) do
            if v.id==fuid then
                return k
            end
        end
        local length=#self.recordInfo
        if length>=10 then
            table.remove(self.recordInfo,10)
        end
        return false
    end
    
    function __Class:showRecordList(isClose)
        if self.isPushDown and isClose then
            return
        end
        self.isPushDown=not self.isPushDown
        -- self.pushDown:setBright(self.isPushDown)
        local scaleY=self.isPushDown and 1 or -1
        -- self.pushDown:setBright(self.isPushDown)
        self.pushDown:setScaleY(scaleY) 
        if self.pushV.bg and not self.isChange then
            self.pushV.bg:setVisible(not self.isPushDown)
        else
            self:initRecordList()
        end
    end
    function __Class:initRecordList()
        self.isChange=false
        self.pushV:removeAllChildren()
        local acountList=PanelUI:new("jediYanmen/serchRecordListView",true) 
        acountList:setPosition(-157,24)
        if acountList.bg~=nil then
            acountList.bg:removeFromParent()
            acountList.bg=nil
        end
        if acountList.bg2~=nil then
            acountList.bg2:removeFromParent()
            acountList.bg2=nil
        end
        local function getBlItem(v)
            --local stu = require("accountList/listItem").create()
            local stu = require("jediYanmen/serchRecorditem").create()
            local item=stu.box
            item:removeSelf()
            item.setData=function (_item,v)
                self:setBlItem(item,v)
            end
            return item
        end
        local listView=acountList:getChild("listView")
        listView:setScrollBarEnabled(false)
        local blItem= require("jediYanmen/serchRecorditem").create()
        listView:plus(blItem.box:getContentSize(),getBlItem)
        listView:upList(self.recordInfo)
        -- listView:scrollToItemVer(0, 0.5)
        self.pushV:addChild(acountList)
        self.pushV.bg=listView
    end
    
    function __Class:setBlItem(item,v)
        local name=UITools.getChild(item,"name");
        local id=UITools.getChild(item,"id");
        name:setString(v.name)
        id:setString(lang("record.bh",v.id))
        local box=UITools.getChild(item,"box");
        item:addClickEventListener(function(sender)
            self:showRecordList()
            self.stu:getChild("gBack","box3","Image_8","Image_7"):getChildByName("editMes"):setText(tostring(v.id))
            self:serch()
        end)
    end
    function __Class:closeMesView(...)
        UICommon.closeDialogAction(self.stu, handler(self, self.hideSelf))
    end
end
