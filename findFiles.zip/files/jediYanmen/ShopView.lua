local PanelUI=require("gameui.PanelUI")
local UITools = require("zeromvc.ui.UITools")

return function (__Class)
function __Class:using(yamenProxy,playerProxy)
    self.yamenProxy = yamenProxy
    self.playerProxy = playerProxy
    local stu=PanelUI:new("yamen.shopView",true)
    stu:offset(display.cx,display.cy)
    self.stu=stu
    UICommon.openDialogAction(stu)
    local function closeHd(...)
        UICommon.closeDialogAction(stu,handler(self,self.hideSelf))
    end
    stu:addEvent("close",closeHd)

    stu:addEvent("checkBoxEvent",function( stu,event,sender,clickType)
        local isHideShop = (clickType == 0)
        self.yamenProxy.isHideShop = isHideShop
        cc.UserDefault:getInstance():setBoolForKey("YAMEN_HIDE_SHOP",isHideShop)
    end)

    self:initWidget()
    self:upView()
    return stu
end

function __Class:upView()
    local shops = self.yamenProxy.fight.shop
    self.listView:removeAllChildren(false)
    for k,v in ipairs(shops) do
        local item=require("yamen/skillItem").create()
        self:setItem(item.box,v)
        item.box:setTag(k)
        item.box:removeSelf(false)
        self.listView:pushBackCustomItem(item.box)
    end
end
function __Class:setItem(item,v)

    UITools.getChild(item,"bg","txt_name"):setString(v.name)
    UITools.getChild(item,"bg","txt_val"):setString(v.desc..v.add.."%")
    UITools.getChild(item,"bg","cnt"):setString(v.need.count)
    UITools.getChild(item,"bg","btn"):setVisible(not self.yamenProxy.fight.shop.isBuy)
    UITools.getChild(item,"bg","geted"):setVisible(v.type == 1)
    UICommon.loadExternalTexture(UITools.getChild(item,"bg","propIcon"),v.buyTypeIcon)
    UICommon.loadExternalTexture(UITools.getChild(item,"bg","skillIcon"),v.icon)
    UITools.getChild(item,"bg","btn"):addClickEventListener(function(sender)
            self:command("JediYanmenCommand.seladd",v)
        end)
end
function __Class:initWidget()
    local fight = self.yamenProxy.fight
    self.listView = self.stu:getChild("gBack","ListView")
    self.stu:getChild("cash","txtValue"):setString(self.playerProxy.user.cash)
    self.stu:getChild("skill","txtValue"):setString(fight.money)
    self.stu:getChild("gBack","actadd","actVal"):setString(fight.ackadd.."%")
    self.stu:getChild("gBack","skilladd","addVal"):setString(fight.skilladd.."%")
    self.stu:getChild("gBack","hp","hpbg","hpText"):setString((math.floor(fight.hp/fight.hpmax*10000)/100) .. "%")
    self.stu:getChild("gBack","hp","hpbg","LoadingBar"):setPercent(fight.hp/fight.hpmax*100)
    self.stu:getChild("checkBox"):setSelected(self.yamenProxy.isHideShop)
end
function __Class:upShopView( ... )
    local fight = self.yamenProxy.fight
    for k,v in ipairs(fight.shop) do
        local item = self.listView:getChildByTag(k)
        if v.type == 0 then
        elseif v.type == 1 then
            UICommon.stampAction(UITools.getChild(item,"bg","geted"))
        end
        UITools.getChild(item,"bg","btn"):setVisible(false)
    end
    self.stu:getChild("skill","txtValue"):setString(fight.money)
    self.stu:getChild("gBack","actadd","actVal"):setString(fight.ackadd.."%")
    self.stu:getChild("gBack","skilladd","addVal"):setString(fight.skilladd.."%")
    self.stu:getChild("gBack","hp","hpbg","hpText"):setString((math.floor(fight.hp/fight.hpmax*10000)/100) .. "%")
    self.stu:getChild("gBack","hp","hpbg","LoadingBar"):setPercent(fight.hp/fight.hpmax*100)

    local act1 = cc.DelayTime:create(1)
    local act2 = cc.CallFunc:create(function()
        UICommon.closeDialogAction(self.stu,handler(self,self.hideSelf))
    end)
    local seq  = cc.Sequence:create(act1,act2)
    self.stu:runAction(seq)
end
function __Class:upUser()
    self.stu:getChild("cash","txtValue"):setString(self.playerProxy.user.cash)
end
end