local PanelUI=require("gameui.PanelUI")
local UITools = require("zeromvc.ui.UITools")

return function (__Class)
function __Class:using(JediYanmenProxy)
    self.yamenProxy = JediYanmenProxy
    self.servantProxy = self.zero:getProxy("game.servant.ServantProxy")
    local stu=PanelUI:new("yamen.fightView")
    stu:offset(0,display.height)
    self.stu=stu
    self.checkFlag = true
    local function closeHd(...)
        self:hideSelf()
    end
    stu:addEvent("close",closeHd)
    stu:addEvent("skip",function ()
        self.log = {}
        self.checkFlag = false
        self:command("JediYanmenCommand.checkWinOrFailed")
    end)
    self:initWidget()
    return stu
end

function __Class:initWidget()
    self.myname         = self.stu:getChild("bg","myPanel","mnameText")
    self.myzz           = self.stu:getChild("bg","myPanel","zzText")
    self.myhpText       = self.stu:getChild("bg","myPanel","hp","hpVal")
    self.myloadingBar   = self.stu:getChild("bg","myPanel","hp","loadingBar")
    self.myheroImg      = self.stu:getChild("bg","myPanel","heroImg")
    self.mytalkBg       = self.stu:getChild("bg","myPanel","talkbg")
    self.mytalkText     = self.stu:getChild("bg","myPanel","talkbg","Text")
    self.myPos          = self.stu:getChild("bg","myPos")

    self.nname          = self.stu:getChild("bg","nPanel","nnameText")
    self.nzz            = self.stu:getChild("bg","nPanel","zzText")
    self.nhpText        = self.stu:getChild("bg","nPanel","hp","hpVal")
    self.nloadingBar    = self.stu:getChild("bg","nPanel","hp","loadingBar")
    self.nheroImg       = self.stu:getChild("bg","nPanel","nheroImg")
    self.ntalkBg        = self.stu:getChild("bg","nPanel","talkbg")
    self.ntalkText      = self.stu:getChild("bg","nPanel","talkbg","Text")
    self.nPos           = self.stu:getChild("bg","nPos")

    self.attack         = self.stu:getChild("bg","yamen")
    self.skillbg        = self.stu:getChild("bg","beijing")
    self.hpCut          = self.stu:getChild("bg","HpCut")
    self.skillTalkbg    = self.stu:getChild("skillTalk")
    self.skillTalkTxt   = self.stu:getChild("skillTalk","Text")
    self.hpCut:setOpacity(0)
    self.mytalkBg:setScale(0)
    self.ntalkBg:setScale(0)
    self.skillTalkbg :setScale(0)
    

    local win = self.yamenProxy.win.fight
    local base = self.yamenProxy.win.fight.base
    self.myhp = base[1].hp
    self.mymaxhp = base[1].hpmax
    self.nhp = base[2].hp
    self.nmaxhp = base[2].hpmax
    self.log = self.yamenProxy.win.fight.log

    local servant1 = self.servantProxy:getHeroById(base[1].hid)
    self.myname:setString(lang("yamen.dj",servant1.name,base[1].level))
    self.myhpText:setString(self.myhp.."/"..self.mymaxhp)
    self.myloadingBar:setPercent(self.myhp/self.mymaxhp*100)
    self.myzz:setString(base[1].azz)
    -- UICommon.loadExternalTexture(self.myheroImg,UICommon.getServantFullIconUrl(base[1].hid))
    UICommon.setServantImg(self.myheroImg,self.servantProxy:getHeroById(base[1].hid),{id=base[1].skin,dt=base[1].dt})
    self.myPvpText = self.yamenProxy:getPVPTextById(base[1].hid)

    local servant2 = self.servantProxy:getHeroById(base[2].hid)
    self.nname:setString(lang("yamen.dj",servant2.name,base[2].level))
    self.nhpText:setString(self.nhp.."/"..self.nmaxhp)
    self.nloadingBar:setPercent(self.nhp/self.nmaxhp*100)
    self.nzz:setString(base[2].azz)
    -- UICommon.loadExternalTexture(self.nheroImg,UICommon.getServantFullIconUrl(base[2].hid))
    UICommon.setServantImg(self.nheroImg,self.servantProxy:getHeroById(base[2].hid),{id=base[2].skin,dt=base[2].dt})
    self.nPvpText = self.yamenProxy:getPVPTextById(base[2].hid)

    self:fighting()

end
function __Class:closeFightView()
    self:hideSelf()
end
function __Class:fighting( ... )
    if self.log == nil or next(self.log) == nil then
        if self.checkFlag then
            self:command("JediYanmenCommand.checkWinOrFailed")
        end
        return 
    end
    local log = table.remove(self.log,1)
    local hero1, hero2, hpText, hpBar, hp, maxhp, attackPos, talkbg, talkText
    local hitText, skillTxt, hitedText, bigScaleRate, smallScaleRate
     -- 0 我动手 1 敌方动手
    hero1       = log.aid == 0 and self.myheroImg    or self.nheroImg
    hero2       = log.aid == 1 and self.myheroImg    or self.nheroImg
    hpText      = log.aid == 1 and self.myhpText     or self.nhpText
    hpBar       = log.aid == 1 and self.myloadingBar or self.nloadingBar
    maxhp       = log.aid == 1 and self.mymaxhp      or self.nmaxhp
    talkbg      = log.aid == 0 and self.mytalkBg     or self.ntalkBg
    talkText    = log.aid == 0 and self.mytalkText   or self.ntalkText
    bigScaleRate= log.aid == 0 and 1.5 or 1.1
    smallScaleRate= log.aid == 0 and 1.3 or 0.9
    local pos   = log.aid == 1 and self.myPos        or self.nPos
    local pvptxt= log.aid == 0 and self.myPvpText    or self.nPvpText
    hitText     = pvptxt.hitText[math.random(1,#pvptxt.hitText)]
    skillTxt    = pvptxt.skillText[math.random(1,#pvptxt.skillText)]
    attackPos   = cc.p(pos:getPositionX(),pos:getPositionY())
    

    self.attack:setPosition(attackPos)
    self.hpCut:setPosition(attackPos)
    self.hpCut:setString(-log.damge)
    talkText:setString(hitText)

    if log.type == 1 then -- 暴击 技能
        self.skillTalkTxt:setString(skillTxt)
        talkbg = self.skillTalkbg
        talkbg:setRotationSkewX(180)
        talkbg:setRotationSkewY(180)
        self.skillTalkTxt:setRotationSkewX(180)
        self.skillTalkTxt:setRotationSkewY(180)
    else
        talkbg:setRotationSkewX(0)
        talkbg:setRotationSkewY(0)
        self.skillTalkTxt:setRotationSkewX(0)
        self.skillTalkTxt:setRotationSkewY(0)
    end


    local act1 = cc.Spawn:create(cc.ScaleTo:create(0.2, bigScaleRate),cc.MoveBy:create(0.2, cc.p(0,50)))
    
    local act6 = cc.CallFunc:create(function()
        local act2 = cc.CallFunc:create(function()
            -- 攻击音效
            self.zero:command("game.yamen.hitNormal")
            -- 攻击
            self.attack:getAnimation():setSpeedScale(1.8)
            self.attack:getAnimation():playWithIndex(0, 1, 0)
            -- 扣血
            if log.aid == 1 then
                self.myhp = log.damge > self.myhp and 0 or self.myhp - log.damge
                hp = self.myhp
            else
                self.nhp = log.damge > self.nhp and 0 or self.nhp - log.damge
                hp = self.nhp
            end
            hpText:setString(hp.."/"..maxhp)
            UICommon.loadingTo(hpBar,hp/maxhp*100,1.2,true)
            -- 打完回去
            local act3 = cc.CallFunc:create(function()
                local act4 = cc.Spawn:create(cc.ScaleTo:create(0.2, smallScaleRate),cc.MoveBy:create(0.2, cc.p(0,-50)))
                local act5 = cc.CallFunc:create(function()
                    self:fighting()
                end)
                hero1:runAction(cc.Sequence:create(act4,act5))
            end)
            -- 飘血
            self.hpCut:runAction(cc.Sequence:create(cc.DelayTime:create(0.2),
                                cc.FadeIn:create(0.05),
                                cc.MoveTo:create(0.6,cc.p(attackPos.x,attackPos.y+150)),
                                cc.FadeOut:create(0.05),act3))

            local act7 = cc.TintTo:create(0.3, 255, 0, 0)
            local act8 = cc.TintTo:create(0.3, 255, 255, 255)
            hero2:runAction(cc.Sequence:create(act7,act8))--  -> 地方变红闪烁
        end)
        local dtime = 0
        if log.type == 1 then
            --  暴击音效
            self.zero:command("game.yamen.hitCrit")
            self.skillbg:getAnimation():playWithIndex(0, 1, 0)
            dtime = 0.7
        end
        talkbg:runAction(cc.Sequence:create(cc.DelayTime:create(dtime),act2))
    end)
    hero1:runAction(cc.Sequence:create(act1))--变大说话同时
    talkbg:runAction(cc.Sequence:create(cc.DelayTime:create(0.3),
                 cc.EaseBackOut:create(cc.ScaleTo:create(0.5, 1)),
                 cc.DelayTime:create(0.3),
                 cc.EaseBackIn:create(cc.ScaleTo:create(0.05, 0)),
                 act6))

end
end