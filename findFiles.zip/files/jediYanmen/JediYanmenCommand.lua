return function (__Class)
    function __Class:init()
        self.JediYanmenProxy = self:getProxy("JediYanmenProxy")
        self.playerProxy = self.zero:getProxy("game.player.PlayerProxy")
        self.activityProxy = self.zero:getProxy("game.activity.ActivityProxy")
    end

    ------------------------------------------------------------------------
    -- 接收 黑名单
    function __Class:loadBlackList(vo)
        -- dump(vo,"SC_loadBlackList")
        -- local chatProxy = self.zero:getProxy("game.chat.ChatProxy")
        -- chatProxy:loadBlackList(vo)
        self.JediYanmenProxy.blackList = vo
        self.JediYanmenProxy:reloadMes(vo)
    end
    
    function __Class:SC_loadChat(vo)
        -- dump(vo, "SC_loadChat")
        self.JediYanmenProxy:loadChat(vo)
        self.JediYanmenProxy:reloadMes(self.JediYanmenProxy.blackList)
        self.JediYanmenProxy:update("updateChat")
    end

    function __Class:CS_checkChat( ... )
        local function cb( ... )
        end
        local vo = newCS()
        vo.info.kuayamen.jdChatCheck = ""
        vo:add(cb,true)
        vo:send()
    end

    function __Class:CS_sendMes(msg)
        local function cb( ... )
            self.JediYanmenProxy:update("scrollToBottom")
        end
        local function gapHd()
            self.JediYanmenProxy:addLimitChat(self.JediYanmenProxy.chatMes,self.JediYanmenProxy.limitMes,self.JediYanmenProxy:createChatMes(msg))
            self.JediYanmenProxy:removeMesWithBl()
            self.JediYanmenProxy:update("updateChat")
        end
        local vo = newCS()
        vo.info.kuayamen.jdChat.msg = msg
        vo:add(handler(self,cb),true,1)
        vo:add(handler(self,gapHd),true,2)
        vo:send()
    end

    -- 获取聊天历史消息
    function __Class:CS_getHistory(mesId)
        local function cb( ... )
            self.zero:command(GameKey.TIP,lang("activity.sucget"))
            -- self.crossShiliProxy:update("scrollToTop")
        end
        local vo = newCS()
        vo.info.kuayamen.jdChatHistory.id = mesId
        vo:add(cb,true)
        vo:send()
    end
    
    function __Class:showChatView(...)
        -- local function cb(...)
            self:show("JediChatView")
        -- end
        -- local vo = newCS()
        -- vo.info.kuayamen.kuafuhistory.id = 1
        -- vo:add(cb, true)
        -- vo:send()
    end
    
    function __Class:showJediYamen(parm)
        local function cb(...)

            if self.JediYanmenProxy.jdyamen.cfg.state == 1 then
                self:show("jediRankView",5)
            elseif self.JediYanmenProxy.jdyamen.cfg.state == 2 then
                self:show("JediYanmenView")
            elseif parm == true then
                self.JediYanmenProxy:update("updateJediYamen")
            else
                self:show("JediYanmenView")
            end
        end
        local vo = newCS()
        vo.info.kuayamen.jdComeHd = {}
        vo:add(cb, true)
        vo:send()
    end
    
    function __Class:showRank(id)
        local function cb(...)
            self:show("jediRankView", id)
        end
        local vo = newCS()
        vo.info.kuayamen.jdGetRank.type = id
        vo:add(cb, true)
        vo:send()
    end

    function __Class:showClubto( id,data )
        
        if id == 1 then 
            self:show("OwnerJediView",data)
        elseif id == 6 then
            self:show("JediDetailsView",data)
        else  
            self:show("jediRankView",4,data)
        end
    end

    function __Class:showOwner( id , data )

        local function cb(...)
            self:showClubto(id,data)
        end
        local vo = newCS()
        if data and id ~= 6 then
            vo.info.kuayamen.getClubInfo.cid = data.cid
        end
        vo.info.kuayamen.jdGetRank.type = 3
        vo:add(cb, true)
        vo:send()
   
    end
    
    function __Class:SC_loadCfg(vo)
        -- dump(vo)
        self.JediYanmenProxy.jdyamen.cfg = vo
        local timeProxy = self.zero:getProxy("game.time.TimeProxy")
        local timeVo = vo.cd
        -- dump(timeVo)
        timeProxy:checkTime(timeVo)
    end

    function __Class:challengeOne( hid,fuid ) -- 挑战一个人
        local function cb(...)
            self:jdPiZhun()
        end
        local vo = newCS()
        vo.info.kuayamen.jdTiaoZhan.hid = hid
        vo.info.kuayamen.jdTiaoZhan.fuid = fuid
        vo:add(cb, true)
        vo:send()
    end

    function __Class:jdPiZhun( ... )
        local function cb(...)
            self:show("ChooseView")
        end
        local vo = newCS()
        vo.info.kuayamen.jdPiZhun = {}
        vo:add(cb, true)
        vo:send()
    end

    function __Class:zhuisha(hid,uid,logId)
        local function cb( ... )
            self:clickHero()
            self.JediYanmenProxy:update("closeMesView")
            self.JediYanmenProxy:update("closeServantView")
        end
        local vo=newCS()
        vo.info.kuayamen.jdZhuiSha.hid = hid
        vo.info.kuayamen.jdZhuiSha.fuid = uid
        vo.info.kuayamen.jdZhuiSha.id = id
        vo:add(cb,true)
        vo:send()
    end
    function __Class:tiaozhan(hid,uid,logId,callback)
        local function cb( ... )
            self:clickHero()
        end
        local vo=newCS()
        vo.info.kuayamen.jdTiaoZhan.hid = hid
        vo.info.kuayamen.jdTiaoZhan.fuid = uid
        -- vo.info.kuayamen.tiaozhan.id = logId
        vo:add(cb,true)
        vo:send()
    end
    function __Class:fuchou(hid,uid,logId,time)
        local function cb( ... )
            self:clickHero()
            self.JediYanmenProxy:update("closeMesView")
            self.JediYanmenProxy:update("closeServantView")
        end
        local vo=newCS()
        vo.info.kuayamen.jdFuChou.hid = hid
        vo.info.kuayamen.jdFuChou.fuid = uid
        vo.info.kuayamen.jdFuChou.id = time
        vo:add(cb,true)
        vo:send()
    end

    function __Class:clickHero( ... )
        self:oneKeyOver()
        self:show("ChooseView")
        if self.JediYanmenProxy.fight.fstate == 2 then
            self:showAwardView()
        end
        
    end

    function __Class:seladd(obj)
        local function cb()
            self.JediYanmenProxy:update("upShopView")
            self.JediYanmenProxy:update("upChooseView")
        end
        local id=obj.id
        local function buffBuy()
            local vo=newCS()
            vo.info.kuayamen.jdSeladd.id = id
            vo:add(cb,true)
            vo:send()
        end
        if id==4 or id==7 or id==10 then
            local fight = self.JediYanmenProxy.fight
            local affter_hp=fight.hp*(1+obj.add*0.01)
            if affter_hp>fight.hpmax then
                self.zero:command(GameKey.POPUP,lang("yamen.bloodOver"),
                    {txt=lang("fight.sure"),callback = function () 
                        buffBuy()
                    end},
                    {txt=lang("marry.cancle"),callback = function ()

                    end})
                return
            end
        end
        buffBuy()
    end

    function __Class:showFightView()
        self:show("FightView")
    end

    function __Class:showShopView( ... )
        self:show("ShopView")
    end

    function __Class:showAwardView()
        self:show("AwardView")
    end

    function __Class:showServantView(uid,type,id,time)
        self:show("ServantView",uid,type,id,time)
    end

    function __Class:fight(id)
        -- self:showAwardView()
        local function cb()
            self:showFightView()
        end
        local function go()
            local vo=newCS()
            vo.info.kuayamen.jdFight.id = id
            vo:add(cb,true)
            vo:send()
        end
        if self.JediYanmenProxy.fight.shop.isBuy == false and self.JediYanmenProxy.isTipBuyAttr == true then
            self.zero:command(GameKey.POPUP,lang("yamen.sure"),
                {txt=lang("fight.sure"),callback = function () 
                    self.JediYanmenProxy.isTipBuyAttr = false 
                    go()
                end},
                {txt=lang("marry.cancle"),callback = function ()
                    self.JediYanmenProxy.isTipBuyAttr = false end
                })
        else
            go()
        end
    end

    function __Class:checkPopup()
        if self.JediYanmenProxy.fight.fstate == 2 then
            self:showAwardView()
        else
            self.JediYanmenProxy:update("closeFightView")
            if self.JediYanmenProxy.win.over.isover == 1 then
                self:oneKeyOver()
                -- self:show("SeeView","over")
            else
                if not self.JediYanmenProxy.isHideShop then
                    self:showShopView()
                end
            end
        end
    end

    function __Class:chushi()
        local function cb( ... )
            self:clickHero()
        end
        local vo=newCS()
        vo.info.kuayamen.jdChushi = {}
        vo:add(cb,true)
        vo:send()
    end
    
    function __Class:checkWinOrFailed()
        if self.JediYanmenProxy.win.fight.win == 0 then -- 战败
            self:show("FailedView")
        elseif self.JediYanmenProxy.win.fight.win == 1 then -- 战胜
            self:show("WinView")
        end
    end

    function __Class:showOneKeyConfirm( ... )
        local activity = self.activityProxy.openActivities[3]
        local gobalSwitchProxy = self.zero:getProxy("game.switch.GobalSwitchProxy")
        if self.playerProxy.user.vip < 6 then
            self.zero:command(GameKey.TIP,lang("yamen.Tip9"))
        elseif activity and activity[254] and (activity[254].eTime - os.time()<=2*60*60) and (activity[254].eTime > os.time()) then
            self.zero:command(GameKey.TIP,lang("yamen.Tip10"))
        else
            if gobalSwitchProxy:getSwitch("YamenOnekeyPlayChange") then
                self:show("OneKeyConfirmNew")
            else
                self:show("OneKeyConfirm")
            end
        end
    end

    function __Class:getrwd(id)
        local function cb()
            self.JediYanmenProxy:update("upAwardView")
        end
        self.zero:command("ka",1)
        self.JediYanmenProxy.seletid = id
        local vo=newCS()
        vo.info.kuayamen.jdGetrwd = {}
        vo:add(cb,true)
        vo:send()
    end

    function __Class:oneKeyPlay( ... )
        local function cb( ... )
            if self.JediYanmenProxy.oneKeyInfo.kill == 0 then
                self:show("OneKeyFailed")
            else
                self:show("OneKeyWin")
            end
        end
        local vo=newCS()
        vo.info.kuayamen.jdOneKeyPlay = {}
        vo:add(cb,true)
        vo:send()
    end

    function __Class:oneKeyPlayNew(id)
        local function cb( ... )
            if self.JediYanmenProxy.oneKeyInfo.kill == 0 then
                self:show("OneKeyFailed",id)
            else
                self:show("OneKeyWin",id)
            end
        end
        local vo=newCS()
        vo.info.kuayamen.jdOneKeyPlay.id = id
        vo:add(cb,true)
        vo:send()
    end

    function __Class:getMoreHistory(id,type)
        local function cb( ... )
            self.JediYanmenProxy:update("upMoreListView")
        end
        local vo=newCS()
        vo.info.kuayamen.jdYamenHistory.id = id
        vo.info.kuayamen.jdYamenHistory.type = type
        vo:add(cb,true)
        vo:send()
    end

    function __Class:oneKeyOver( ... )
        self.JediYanmenProxy:update("closeChooseView")
        self.JediYanmenProxy:update("closeServantView")
        self.JediYanmenProxy:update("closejediChallenge")
        self.JediYanmenProxy:update("closejediRank")
    end

    function __Class:find(id)
        local vo=newCS()
        vo.info.kuayamen.jdFindZhuiSha.fuid = id
        vo:send()
    end

    function __Class:showMesView( id,type )
        local function cb( ... )
            self:show("MesView",1)
        end
        local vo=newCS()
        vo.info.kuayamen.jdYamenHistory.id = id
        vo.info.kuayamen.jdYamenHistory.type = type
        vo:add(cb,true)
        vo:send()
    end

    function __Class:randomChallenge( ... )
        -- body     jdSjtz
        local function cb( ... )
            self:jdPiZhun()
        end
        local vo=newCS()
        vo.info.kuayamen.jdSjtz = {}
        vo:add(cb,true)
        vo:send()
    end

    function __Class:SC_loadDielist(vo)
        -- dump(vo)
        self.JediYanmenProxy.jdyamen.dielist = vo
        self.JediYanmenProxy:setClubInfos(vo)
        -- for i,v in ipairs(vo) do
        --     if self.playerProxy.user.uid == v.uid then
        --         self.JediYanmenProxy.jdyamen.user.rid = v.rid
        --         self.JediYanmenProxy.jdyamen.user.score = v.score
        --         self.JediYanmenProxy.jdyamen.user.win = 0
        --     end
        -- end
    end

    function __Class:SC_loadScorelist(vo)
        -- dump(vo)
        self.JediYanmenProxy.jdyamen.scorelist = vo
        self.JediYanmenProxy:setClubInfos(vo)
        -- for i,v in ipairs(vo) do
        --     if self.playerProxy.user.uid == v.uid then
        --         self.JediYanmenProxy.jdyamen.user.rid = v.rid
        --         self.JediYanmenProxy.jdyamen.user.score = v.score
        --         self.JediYanmenProxy.jdyamen.user.win = 1
        --     end
        -- end
    end

    function __Class:SC_loadClubInfo( vo )
        -- dump(vo)
        table.sort(vo.members,function ( a,b )
            return a.rid < b.rid
        end)
        self.JediYanmenProxy.jdyamen.clubInfo = vo.members
        self.JediYanmenProxy.jdyamen.clubRid = vo.rid
    end
    
    function __Class:SC_loadClubRankList(vo)
        self.JediYanmenProxy.jdyamen.clubRankList = vo
        if self.JediYanmenProxy.jdyamen.clubRankList then
            table.sort( self.JediYanmenProxy.jdyamen.clubRankList, function ( a,b )
                return a.rid < b.rid
            end )
            -- for i,v in ipairs(self.JediYanmenProxy.jdyamen.clubRankList) do
            --     v.rid = i
            -- end
        end
    end
    
    function __Class:SC_loadUserList(vo)
        -- self.JediYanmenProxy.jdyamen.userList = vo
    end
    
    function __Class:SC_loadFClist(vo)
        self.JediYanmenProxy.jdyamen.clist = vo
    end
    
    function __Class:SC_loadEnymsg(vo)
        self.JediYanmenProxy.jdyamen.enymsg = vo
    end
    
    -- function __Class:SC_loadChat(vo)
    --     self.JediYanmenProxy.jdyamen.chat = vo
    -- end
    
    function __Class:SC_loadZhuisha(vo)
        self.JediYanmenProxy.jdyamen.zhuisha = vo
    end
    
    function __Class:SC_loadCslist(vo)
        self.JediYanmenProxy.jdyamen.cslist = vo
    end
    
    function __Class:SC_loadDeflog(vo)
        self.JediYanmenProxy.jdyamen.deflog = vo
    end
    
    function __Class:SC_loadUser(vo)
        self.JediYanmenProxy.jdyamen.user = vo
    end
    
    function __Class:SC_loadWin(vo)
        -- self.JediYanmenProxy.jdyamen.win = vo
        self.JediYanmenProxy:loadWin(vo)
    end
    
    function __Class:SC_loadFight(vo)
        -- self.JediYanmenProxy.jdyamen.fight = vo
        self.JediYanmenProxy:loadFight(vo)
    end
    
    function __Class:SC_loadOnekey(vo)
        self.JediYanmenProxy.jdyamen.onekey = vo
    end
    
    function __Class:SC_loadInfo(vo)
        self.JediYanmenProxy.jdyamen.info = vo

        local timeProxy = self.zero:getProxy("game.time.TimeProxy")
        local timeVo = vo.cd
        timeProxy:checkTime(timeVo)
    end

    function __Class:SC_loadYuxuan(vo)
        self.JediYanmenProxy.jdyamen.yuxuan = vo
    end
    
    function __Class:SC_loadClublist(vo)
        -- dump(vo)
        -- self.JediYanmenProxy.jdyamen.clublist = vo
        -- self.JediYanmenProxy:setClubInfo(vo)
    end
    
end
