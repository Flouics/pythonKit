-- 活动聊天
local PanelUI=require("gameui.PanelUI")
local UITools=require("zeromvc.ui.UITools")

local color = {cc.c3b(97,62,7),cc.c3b(155,3,3),cc.c3b(137,52,0),cc.c3b(51,85,148),cc.c3b(128,6,86)}

return function (__Class)
function __Class:using(JediYanmenProxy)
    self.jediYanmenProxy = JediYanmenProxy
    self.playerProxy = self.zero:getProxy("game.player.PlayerProxy")

    -- local stu = PanelUI:new("crossshili.chatView",true)
    local stu = PanelUI:new("crossCapital.chatViewNew",true)
    
    -- stu:offset(display.cx,display.cy)
    stu:offset(0,display.height)
    self.stu = stu

    self.stu:addEvent("close",function()
        self:hideSelf()
        self:used()
    end)

    stu:addEvent("blackEvent",function( ... )
        self.zero:command("game.chat.ChatCommand.showBlackView")
    end)

    self:initWidget()

    return stu
end

function __Class:initListView()
    local data = self.jediYanmenProxy.chatMes
    local listView = self.stu:getChild("listView")
    listView:setBounceEnabled(true)
    listView:setScrollBarEnabled(false)
    listView:setClippingType(1)
    self.listView = listView

    local function getItem(v)
        -- local stu = require("crossshili/chatItem").create()
        local stu = require("crossCapital/chatItemNew").create()
        
        local item=stu.box
        item:removeSelf()
        item.setData=function (_item,v)
            self:setBlItem(item,v)
        end
        return item
    end

    local TestItem = require("crossCapital/chatItemNew").create()
    listView:plus(TestItem.box:getContentSize(),getItem)
    listView:upList(data)

    local isCanGetMes = true
    local listViewheight = listView:getContentSize().height
    local function scrollViewEvent(sender,evenType)
        sender:scrollHd(evenType)

        if evenType ==  ccui.ScrollviewEventType.scrollToTop then
            isCanGetMes = true
        elseif evenType == ccui.ScrollviewEventType.bounceTop then
            local height = sender:getInnerContainerSize().height
            if isCanGetMes and (sender:getInnerContainerPosition().y < (listViewheight-height-100)) then
                isCanGetMes = false
                local mes = self.jediYanmenProxy.chatMes[1]
                if mes ~= nil and mes.id > 1 then
                    self:command("JediYanmenCommand.CS_getHistory",mes.id)
                end
            end
        end
    end
    listView:addScrollViewEventListener(scrollViewEvent)
    self:scrollToBottom()
end

function __Class:setItem(item,v)
    local vipImg = UITools.getChild(item,"vipImg")
    local nameText = UITools.getChild(item,"nameText")
    local underline = UITools.getChild(item,"nameText","underline")
    local chImg = UITools.getChild(item,"chImg")
    chImg:ignoreContentAdaptWithSize(true)
    
    nameText:setString(v.user.name)
    underline:setContentSize(cc.size(nameText:getContentSize().width + 6,2))
    UITools.getChild(item,"mesText"):setString(v.msg)
    UITools.getChild(item,"timeText"):setString(lang("speTimeDiff",v.time))

    item:addClickEventListener(function(sender)
        self.zero:command("game.rank.RankCommand.showRoleView",v.user.uid,false,true)
    end)
    
    UITools.getChild(item,"areaBg","area"):setString(lang("set.serverQu",self.playerProxy:getArea(v.user.uid)))

    UITools.getChild(item,"bg1"):setVisible(UICommon.getChenghaoChatBg(v.user.chenghao) == 0)
    UITools.getChild(item,"bg2"):setVisible(UICommon.getChenghaoChatBg(v.user.chenghao) == 1)
    UITools.getChild(item,"bg3"):setVisible(UICommon.getChenghaoChatBg(v.user.chenghao) == 2) -- 皇帝
    UITools.getChild(item,"bg4"):setVisible(UICommon.getChenghaoChatBg(v.user.chenghao) == 3) -- 帝
    UITools.getChild(item,"mesText"):disableEffect()
    vipImg:removeAllChildren()

    local chenghao  =  v.user.chenghao
    local color1,color2 = UICommon.getChenghaoColor(chenghao)
    UITools.getChild(item,"mesText"):setTextColor(color1)
    if UICommon.getIsShowChengHao(chenghao) then
        if color2 then
            UITools.getChild(item,"mesText"):enableOutline(color2,1)        
        end  
        vipImg:setVisible(false)
        chImg:setVisible(true)
        UICommon.loadExternalTexture(chImg,UICommon.getUserTitle1IconUrl(chenghao))
        chImg:setPositionX(nameText:getPositionX() + nameText:getContentSize().width + 10)
    elseif v.user.vip > 0 then
        UICommon.loadExternalTexture(vipImg,UICommon.getVipIconUrl(v.user.vip))
        vipImg:setPositionX(nameText:getPositionX() + nameText:getContentSize().width + 10)
        vipImg:setVisible(true)
        chImg:setVisible(false)
        if v.user.vip and (v.user.vip == 13 or v.user.vip == 14) then
            local armature = ccs.Armature:create()
            armature:init("vip13texiao")
            armature:getAnimation():playWithIndex(0)
            armature:setPosition(cc.p(90,30))
            vipImg:addChild(armature)
        elseif v.user.vip and v.user.vip == 15 then
            local armature = ccs.Armature:create()
            armature:init("vip15texiao")
            armature:getAnimation():playWithIndex(0)
            armature:setPosition(cc.p(90,28))
            vipImg:addChild(armature)
        end
    else
        vipImg:setVisible(false)
        chImg:setVisible(false)
    end
    local effect = item:getChildByTag(51)
    if chenghao == 22 or chenghao == 29 and effect ~=nil then
        chImg:setPositionX(nameText:getPositionX() + nameText:getContentSize().width + 20)
        effect:setVisible(true) -- 皇帝
        effect:setPositionX(chImg:getPositionX() + 60)
    else
        effect:setVisible(false)
    end
    UICommon.setOfflineCh(item,chImg,vipImg,nameText,v.user.offlineCh)
end

function __Class:setBlItem(item,v)
    local vipImg = UITools.getChild(item,"vipImg")
    local chImg = UITools.getChild(item,"chImg")
    local nameText = UITools.getChild(item,"nameText")
    local underline = UITools.getChild(item,"nameText","underline")
    
    local mesText = UITools.getChild(item,"mesText")
    local qipao = UITools.getChild(item,"qipao")
    local kuang = UITools.getChild(item,"imgFrame")
    local tbg = UITools.getChild(item,"tbg")
    local timeText = UITools.getChild(item,"timeText")
    local areaBg = UITools.getChild(item,"areaBg")
    qipao:setAnchorPoint(0,1)
    nameText:setString(v.user.name)
    underline:setContentSize(cc.size(nameText:getContentSize().width + 6,2))

    UITools.getChild(item,"area"):setString(lang("set.serverQu",self.playerProxy:getArea(v.user.uid)))
    UITools.getChild(item,"timeText"):setString(lang("speTimeDiff",v.time))
    if v.user.uid==self.playerProxy.user.uid then
        tbg:setScaleX(-1)
        tbg:setPositionX(656)
        qipao:setScaleX(-1)
        qipao:setPositionX(580.71)
        mesText:setAnchorPoint(1,0.5)
        mesText:setPositionX(550)
        mesText:setTextHorizontalAlignment(0)
        kuang:setPositionX(648)
        nameText:setAnchorPoint(1,0.5)
        nameText:setPositionX(565)
        UITools.getChild(item,"area"):setPositionX(660)
        areaBg:setPositionX(660)
        timeText:setAnchorPoint(0,0.5)
        timeText:setPositionX(15)
        qipao:setCapInsets({x = 33, y = 32, width = 25, height = 12})
    else
        tbg:setScaleX(1)
        tbg:setPositionX(88)
        qipao:setScaleX(1)
        qipao:setPositionX(153)
        mesText:setAnchorPoint(0,0.5)
        mesText:setPositionX(173)
        mesText:setTextHorizontalAlignment(0)
        kuang:setPositionX(75)
        nameText:setAnchorPoint(0,0.5)
        nameText:setPositionX(175)
        UITools.getChild(item,"area"):setPositionX(77)
        areaBg:setPositionX(77)
        timeText:setAnchorPoint(1,0.5)
        timeText:setPositionX(713)
        qipao:setCapInsets({x = 33, y = 32, width = 25, height = 12})
    end
    if Config.appHide ~= "1" then
        UICommon.loadExternalTexture(kuang,"assetsRes/res/player/userFrameUI/defaultFrame.png")
        local data=self.playerProxy:getUserFrameConf(v.user.frame)
        UICommon.loadExternalTexture(kuang,UICommon.getUserFrame(data.icon))
        kuang:ignoreContentAdaptWithSize(true)
        UICommon.addHeadImg(kuang,v.user)
        if v.user.chatFrame == 0 then
            if v.user.uid==self.playerProxy.user.uid then
                UICommon.loadExternalTexture(qipao,"assetsRes/res/player/chatFrame/my0.png")
                qipao:setScaleX(-1)
                -- qipao:setAnchorPoint(1,1)
                qipao:setPositionX(580)
                qipao:setCapInsets({x = 33, y = 32, width = 25, height = 12})
            else
                UICommon.loadExternalTexture(qipao,UICommon.getUserChatFrame(v.user.chatFrame))
            end
        else
            local data=self.playerProxy:getUserChatFrameConf(v.user.chatFrame)
            UICommon.loadExternalTexture(qipao,UICommon.getUserChatFrame(data.icon))
            qipao:setCapInsets({x = 33, y = 32, width = 25, height = 12})
        end
    else
        UICommon.addHeadImg(kuang,v.user,true)
    end

    mesText:ignoreContentAdaptWithSize(true)
    mesText:setTextAreaSize({width = 0, height = 0})
    mesText:setString(v.msg)
    local mesSize=mesText:getContentSize()
    qipao:setContentSize(150,100)--初始
    if mesSize.width>100 then
        if mesSize.width<=400 then
            qipao:setContentSize(400+mesSize.width-320,100)
        else
            mesText:ignoreContentAdaptWithSize(false)
            mesText:setContentSize(450, 52)
            mesText:setTextVerticalAlignment(1)
            qipao:setContentSize(505,100)
        end
    end
    

    vipImg:removeAllChildren()
    local chatFrame  =  v.user.chatFrame
    local color1,color2 = UICommon.getChenghaoColor(chatFrame)
    mesText:setTextColor(color1)
    if v.user.chenghao > 0 and UICommon.isNoChenghaoIcon(v.user.chenghao) ~= true then
        vipImg:setVisible(false)
        chImg:setVisible(true)
        local posx = 0
        UICommon.loadExternalTexture(chImg,UICommon.getUserTitle1IconUrl(v.user.chenghao))
        if v.user.uid==self.playerProxy.user.uid then
           posx = nameText:getPositionX() - nameText:getContentSize().width-chImg:getContentSize().width+30
        else
            posx = nameText:getPositionX() + nameText:getContentSize().width
        end
        chImg:setPositionX(posx)
    elseif v.user.vip > 0 then
        UICommon.loadExternalTexture(vipImg,UICommon.getVipIconUrl(v.user.vip))
        chImg:setVisible(false)
        vipImg:setVisible(true)
        local posx = 0
        if v.user.uid==self.playerProxy.user.uid then
            posx = nameText:getPositionX() - nameText:getContentSize().width-vipImg:getContentSize().width+30
        else
            posx = nameText:getPositionX() + nameText:getContentSize().width
        end
        vipImg:setPositionX(posx)
    else
        vipImg:setVisible(false)
        chImg:setVisible(false)
    end
    --UICommon.setOfflineCh(item,chImg,vipImg,nameText,v.user.offlineCh,v.user.uid==self.playerProxy.user.uid)

    nameText:addClickEventListener(function(sender)
        self.zero:command("game.rank.RankCommand.showRoleView",v.user.uid,false,true)
    end)
    kuang:addClickEventListener(function(sender)
        self.zero:command("game.rank.RankCommand.showRoleView",v.user.uid,false,true)
    end)
end

function __Class:initWidget()
    self:initListView()
    -- --------------输入框
   local cntText = self.stu:getChild("inputBox","cntText")
   local function editBoxTextEventHandle(strEventName,pSender)
        local edit = pSender
        local strFmt = ""
        if strEventName == "began" then
        elseif strEventName == "ended" then
        elseif strEventName == "return" then
            strFmt = self:filterSpecChars(edit:getText())
            cntText:setString(string.utf8len(strFmt).."/40")
            edit:setText(strFmt)
        elseif strEventName == "changed" then
            strFmt = self:filterSpecChars(edit:getText())
            cntText:setString(string.utf8len(strFmt).."/40")
        end
    end    
    local inputPanel = self.stu:getChild("inputBox","inputPanel")
    local inputSize = inputPanel:getContentSize()
    local editMes = ccui.EditBox:create(inputSize,"assetsRes/res/beijing/beijing130.png")
    editMes:registerScriptEditBoxHandler(editBoxTextEventHandle)    
    editMes:setPosition(cc.p(inputSize.width/2, inputSize.height/2))
    editMes:setFontName(UICommon.getTTFName())
    editMes:setFontSize(25)
    editMes:setFontColor(cc.c3b(255,128,0))
    editMes:setPlaceHolder(lang("crossyamen.input"))
    editMes:setPlaceholderFontColor(cc.c3b(255,255,255))
    editMes:setPlaceholderFontSize(25)
    editMes:setMaxLength(40)
    editMes:setReturnType(cc.KEYBOARD_RETURNTYPE_DONE)
    self.stu:getChild("inputBox","inputPanel"):addChild(editMes)
    
    
    local function sendHd(...)
        local mes = self:filterSpecChars(editMes:getText())
        if mes ~= "" then
            self:command("JediYanmenCommand.CS_sendMes",mes)
            cntText:setString("0/40")
            editMes:setText("")
        else
            self.zero:command(GameKey.TIP,lang("crossyamen.not_null"))
        end
        self.zero:command("game.player.chat")
    end
    self.stu:addEvent("sendEvent",sendHd)
    self.scheduleId = cc.Director:getInstance():getScheduler():scheduleScriptFunc(function ( ... )
        self:command("JediYanmenCommand.CS_checkChat")
    end,5,false)
end

function __Class:filterSpecChars(s)
    local ss = {}  
    for k = 1, #s do  
        local c = string.byte(s,k)  
        if not c then break end  
        --if (c>=48 and c<=57) or (c>= 65 and c<=90) or (c>=97 and c<=122) then  
        if c < 127 and c ~= 10 and c ~= 47 and c~= 92 then
            table.insert(ss, string.char(c))  
        elseif c>=224 and c<=239 then
            local c1 = string.byte(s,k+1)
            local c2 = string.byte(s,k+2)
            if c1 and c2 then  
                local a1,a2,a3,a4 = 128,191,128,191  
                if c == 228 then a1 = 184  
                elseif c == 233 then a2,a4 = 190,c1 ~= 190 and 191 or 165  
                end  
                if c1>=a1 and c1<=a2 and c2>=a3 and c2<=a4 then  
                    k = k + 2  
                    table.insert(ss, string.char(c,c1,c2))
                end  
            end  
        end  
    end  
    return table.concat(ss)
end

function __Class:updateChat()
    self.listView:upList(self.jediYanmenProxy.chatMes)
    self:scrollToBottom()
end

function __Class:scrollToBottom()
    if self.listView:getInnerContainerPosition().y == 0 then
        self.listView:scrollToPercentVertical(100,0.5,true)
    end
end

function __Class:scrollToTop()
    self.listView:scrollToPercentVertical(0,0.5,true)
end

function __Class:used()
    cc.Director:getInstance():getScheduler():unscheduleScriptEntry(self.scheduleId)
end

end