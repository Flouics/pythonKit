local PanelUI=require("gameui.PanelUI")
local UITools = require("zeromvc.ui.UITools")

return function (__Class)
function __Class:using(yamenProxy)
    self.yamenProxy = yamenProxy
    local stu=PanelUI:new("yamen.winView",true)
    stu:offset(display.cx,display.cy)
    self.stu=stu
    --胜利音效
    self.zero:command("game.yamen.fightS")

    local function closeHd()
        self:command("JediYanmenCommand.checkPopup")
        self:hideSelf()
    end
    stu.bg:addEvent("HIT",closeHd)
    self:initWidget()
    return stu
end
function __Class:initWidget()
    local info = self.yamenProxy.win.fight
    dump(info,"胜利的数据---------------------")
    self.stu:getChild("bg","txt_2","txt_3"):setString("+"..info.items[1].count)
    self.stu:getChild("bg","txt_4","txt_5"):setString("+"..info.items[2].count)
    self.stu:getChild("txtValue"):setString("+"..info.items[3].count)
    self.stu:getChild("lsVal"):setString(info.winnum)
    self.stu:getChild("Img2","zVal"):setString(info.nrwd)
    if info.nrwd == 3 then 
        self.stu:getChild("Img2"):setVisible(false)
    else 
        self.stu:getChild("Img1"):setVisible(false)
    end
end
end