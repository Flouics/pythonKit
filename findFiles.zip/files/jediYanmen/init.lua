local zeromvc = require "zeromvc.zeromvc"
local __Class = zeromvc.classCommand(...)
local Timer = require "zeromvc.core.Timer"

function __Class:init()
    local keys = {      
		{type="view", name="JediYanmenView",proxys={"JediYanmenProxy","game.time.TimeProxy"}}, 
		{type="view", name="OwnerJediView",proxys={"JediYanmenProxy","game.time.TimeProxy"}}, 
		{type="view", name="TheirJediView",proxys={"JediYanmenProxy","game.time.TimeProxy"}}, 
		{type="view", name="JediDetailsView",proxys={"JediYanmenProxy","game.time.TimeProxy"}}, 
		{type="view", name="JediChatView",proxys={"JediYanmenProxy","game.time.TimeProxy"}},
		{type="view", name="jediRankView",proxys={"JediYanmenProxy","game.time.TimeProxy"}},
        {type="view", name="JediChallenge",proxys={"JediYanmenProxy","game.time.TimeProxy"}},
        {type="view", name="ChooseView",proxys={"JediYanmenProxy","game.time.TimeProxy"}},
        {type="view", name="ShopView",proxys={"JediYanmenProxy","game.player.PlayerProxy"}},
        {type="view", name="FightView",proxys={"JediYanmenProxy","game.player.PlayerProxy"}},
        {type="view", name="WinView",proxys={"JediYanmenProxy","game.player.PlayerProxy"}},
        {type="view", name="FailedView",proxys={"JediYanmenProxy","game.player.PlayerProxy"}},
        {type="view", name="AwardView",proxys={"JediYanmenProxy","game.player.PlayerProxy"}},
        {type="view", name="OneKeyConfirm",proxys={"JediYanmenProxy","game.player.PlayerProxy"}},
        {type="view", name="OneKeyWin",proxys={"JediYanmenProxy","game.player.PlayerProxy"}},
        {type="view", name="OneKeyFailed",proxys={"JediYanmenProxy","game.player.PlayerProxy"}},
        {type="view", name="ServantView",proxys={"JediYanmenProxy","game.player.PlayerProxy"}},
        {type="view", name="MesView",proxys={"JediYanmenProxy","game.player.PlayerProxy"}},
        {type="view", name="OneKeyConfirmNew",proxys={"JediYanmenProxy","game.player.PlayerProxy"}},

		{type="command",name="JediYanmenCommand",fn="showChatView"},
		{type="command",name="JediYanmenCommand",fn="showJediYamen"},
        {type="command",name="JediYanmenCommand",fn="showRank"},
        {type="command",name="JediYanmenCommand",fn="showClub"},
        {type="command",name="JediYanmenCommand",fn="showOwner"},
        {type="command",name="JediYanmenCommand",fn="CS_sendMes"},
        {type="command",name="JediYanmenCommand",fn="CS_checkChat"},
        {type="command",name="JediYanmenCommand",fn="CS_getHistory"},
        {type="command",name="JediYanmenCommand",fn="challengeOne"},
        {type="command",name="JediYanmenCommand",fn="jdPiZhun"},
        {type="command",name="JediYanmenCommand",fn="seladd"},
        {type="command",name="JediYanmenCommand",fn="fight"},
        {type="command",name="JediYanmenCommand",fn="checkWinOrFailed"},
        {type="command",name="JediYanmenCommand",fn="checkPopup"},
        {type="command",name="JediYanmenCommand",fn="showOneKeyConfirm"},
        {type="command",name="JediYanmenCommand",fn="getrwd"},
        {type="command",name="JediYanmenCommand",fn="oneKeyOver"},
        {type="command",name="JediYanmenCommand",fn="oneKeyPlay"},
        {type="command",name="JediYanmenCommand",fn="getMoreHistory"},
        {type="command",name="JediYanmenCommand",fn="showServantView"},
        {type="command",name="JediYanmenCommand",fn="tiaozhan"},
        {type="command",name="JediYanmenCommand",fn="zhuisha"},
        {type="command",name="JediYanmenCommand",fn="fuchou"},
        {type="command",name="JediYanmenCommand",fn="find"},
        {type="command",name="JediYanmenCommand",fn="showMesView"},
        {type="command",name="JediYanmenCommand",fn="randomChallenge"},
        {type="command",name="JediYanmenCommand",fn="oneKeyPlayNew"},
        {type="command",name="JediYanmenCommand",fn="chushi"},
        {type="command",name="JediYanmenCommand",fn="clickHero"},

        {type="command",name="JediYanmenCommand",fn="SC_loadCfg"},
        {type="command",name="JediYanmenCommand",fn="SC_loadScorelist"},
        {type="command",name="JediYanmenCommand",fn="SC_loadClubInfo"},
        {type="command",name="JediYanmenCommand",fn="SC_loadDielist"},
        {type="command",name="JediYanmenCommand",fn="SC_loadClubRankList"},

        {type="command",name="JediYanmenCommand",fn="SC_loadFClist"},
        {type="command",name="JediYanmenCommand",fn="SC_loadEnymsg"},
        {type="command",name="JediYanmenCommand",fn="SC_loadChat"},
        {type="command",name="JediYanmenCommand",fn="SC_loadZhuisha"},
        {type="command",name="JediYanmenCommand",fn="SC_loadCslist"},

        {type="command",name="JediYanmenCommand",fn="SC_loadDeflog"},
        {type="command",name="JediYanmenCommand",fn="SC_loadUser"},
        {type="command",name="JediYanmenCommand",fn="SC_loadWin"},
        {type="command",name="JediYanmenCommand",fn="SC_loadFight"},
        {type="command",name="JediYanmenCommand",fn="SC_loadOnekey"},
        {type="command",name="JediYanmenCommand",fn="SC_loadYuxuan"},

        {type="command",name="JediYanmenCommand",fn="SC_loadInfo"},
        {type="command",name="JediYanmenCommand",fn="SC_loaduxuan"},
    }
    self:addEsay(keys)

    --------------- self:addSc("JediYanmenCommand","SC_loadChat","kuacbhuodong","chat")

    -- self:addSc("JediYanmenCommand","SC_loadCfg","jdyamen","cfg")
    -- self:addSc("JediYanmenCommand","SC_loadScorelist","jdyamen","scorelist")
    -- self:addSc("JediYanmenCommand","SC_loadClubInfo","jdyamen","clubInfo")
    -- self:addSc("JediYanmenCommand","SC_loadDielist","jdyamen","dielist")
    -- self:addSc("JediYanmenCommand","SC_loadClubRankList","jdyamen","clubRankList")

 
    -- self:addSc("JediYanmenCommand","SC_loadFClist","jdyamen","fclist")
    -- self:addSc("JediYanmenCommand","SC_loadEnymsg","jdyamen","enymsg")
    -- self:addSc("JediYanmenCommand","SC_loadChat","jdyamen","chat")
    -- self:addSc("JediYanmenCommand","SC_loadZhuisha","jdyamen","zhuisha")
    -- self:addSc("JediYanmenCommand","SC_loadCslist","jdyamen","cslist")

    -- self:addSc("JediYanmenCommand","SC_loadDeflog","jdyamen","deflog")
    -- self:addSc("JediYanmenCommand","SC_loadUser","jdyamen","user")
    -- self:addSc("JediYanmenCommand","SC_loadWin","jdyamen","win")
    -- self:addSc("JediYanmenCommand","SC_loadFight","jdyamen","fight")
    -- self:addSc("JediYanmenCommand","SC_loadOnekey","jdyamen","onekey")

    -- self:addSc("JediYanmenCommand","SC_loadInfo","jdyamen","info")  
    -- self:addSc("JediYanmenCommand","SC_loaduxuan","jdyamen","yuxuan")

    --------------- self:addSc("JediYanmenCommand","SC_loadBlackList","jdyamen","chat")
    self.jediYanmenProxy = self:getProxy("JediYanmenProxy")
    sc.jdyamen:addEvent("onekey",function (vo)
        self.jediYanmenProxy.oneKeyInfo = vo.onekey:soul()
    end)
    sc.jdyamen:addEvent("kill20log",function (vo)
        self.jediYanmenProxy:loadKill20log(vo.kill20log:soul())
        self.jediYanmenProxy:update("upKilllog20")
    end)

    sc.jdyamen:addEvent("fclist",function (vo)
        self.jediYanmenProxy:loadFclist(vo.fclist:soul())
    end)

    sc.jdyamen:addEvent("zhuisha",function (vo)
        self.jediYanmenProxy.zhuisha = vo.zhuisha:soul()
        self.jediYanmenProxy:update("upBox3")
    end)
    sc.jdyamen:addEvent("deflog",function (vo)
        self.jediYanmenProxy:loadDeflog(vo.deflog:soul())
    end)

    sc.jdyamen:addEvent("enymsg",function (vo)
        self.jediYanmenProxy:loadEnymsg(vo.enymsg:soul())
    end)
    sc:addEvent("jdyamen",function (vo)
        
        self:command("JediYanmenCommand.SC_loadUser",vo.jdyamen.user:soul())
        self:command("JediYanmenCommand.SC_loadCfg",vo.jdyamen.cfg:soul())
        self:command("JediYanmenCommand.SC_loadScorelist",vo.jdyamen.scorelist:soul())
        self:command("JediYanmenCommand.SC_loadClubInfo",vo.jdyamen.clubInfo:soul())
        self:command("JediYanmenCommand.SC_loadDielist",vo.jdyamen.dielist:soul())
        self:command("JediYanmenCommand.SC_loadClubRankList",vo.jdyamen.clubRankList:soul())

        self:command("JediYanmenCommand.SC_loadFClist",vo.jdyamen.fclist:soul())
        self:command("JediYanmenCommand.SC_loadEnymsg",vo.jdyamen.enymsg:soul())
        self:command("JediYanmenCommand.SC_loadChat",vo.jdyamen.chat:soul())
        self:command("JediYanmenCommand.SC_loadZhuisha",vo.jdyamen.zhuisha:soul())
        self:command("JediYanmenCommand.SC_loadCslist",vo.jdyamen.cslist:soul())

        self:command("JediYanmenCommand.SC_loadDeflog",vo.jdyamen.deflog:soul())
        self:command("JediYanmenCommand.SC_loadWin",vo.jdyamen.win:soul())
        self:command("JediYanmenCommand.SC_loadFight",vo.jdyamen.fight:soul())
        self:command("JediYanmenCommand.SC_loadOnekey",vo.jdyamen.onekey:soul())

        self:command("JediYanmenCommand.SC_loadInfo",vo.jdyamen.info:soul())
        self:command("JediYanmenCommand.SC_loadYuxuan",vo.jdyamen.yuxuan:soul())
        self.jediYanmenProxy.jdyamen.userList  = vo.jdyamen.userList:soul()
        self.jediYanmenProxy.jdyamen.clublist = vo.jdyamen.clublist:soul()
        self.jediYanmenProxy.allUserList = clone(self.jediYanmenProxy.jdyamen.scorelist)
        table.insertto(self.jediYanmenProxy.allUserList,clone(self.jediYanmenProxy.jdyamen.dielist))
        self.jediYanmenProxy:setClubInfo(vo.jdyamen.clublist:soul())
        self.jediYanmenProxy:update("updateJediYamen")

    end)
    self:addSc("JediYanmenCommand","loadBlackList","chat","blacklist")
end

function __Class:execute()

end

return __Class