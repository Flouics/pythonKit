local PanelUI = require("gameui.PanelUI")
local UITools = require("zeromvc.ui.UITools")
local ThingIconUI=require("gameui.ThingIcon")
local TabFM = require "gameui.TabFM"
return function (__Class)
    
    function __Class:using(proxy, TimeProxy)
        self.timeProxy = TimeProxy
        self.universeProxy = self.zero:getProxy("game.universe.UniverseProxy")
        self.activityProxy =self.zero:getProxy("game.activity.ActivityProxy")
        self.proxy = proxy;
        local stu = PanelUI:new("jediYanmen.jediDetailsView")
        self.stu = stu;
        self.scrollView1 = self.stu:getChild("box1","listView1")
        self.listview2 = self.stu:getChild("box2","listView2")
        
        stu:addEvent("close", function()
            self:hideSelf()
        end)

        self.clubInfo = clone(self.jediYanmenProxy.jdyamen.clubInfo)
        self.myClub = self.clubInfo[1]
        self.stop1 = nil
        self.stop2 = nil

        self:initWidget()
        local tab = TabFM:new()
        tab:addBtn(self.stu:getChild("box1"), self.listview1)
        tab:addBtn(self.stu:getChild("box2"), self.listview2)
        tab:addEvent("cut", function (sender, type, id)
            if id == 1 then
                self:initBox1()
                if self.proxy.jdyamen.user and  self.proxy.jdyamen.user.rid ~= 0 then
                    self.stu:getChild("box2_0","myRank"):setString(lang("juediyamen.myrank",self.proxy.jdyamen.user.rid))
                else
                    self.stu:getChild("box2_0","myRank"):setString(lang("juediyamen.myrank",lang("champion.nojoin")))
                end
                self.stu:getChild("box1","listView1"):setVisible(true)
                self.stu:getChild("box2","listView2"):setVisible(false)
                self.stu:getChild("box1","btnTotal"):setVisible(true)
                self.stu:getChild("box2","btnTotal"):setVisible(false)
            elseif id == 2 then
                self:initBox2()
                if self.jediYanmenProxy.jdyamen.user and self.jediYanmenProxy.jdyamen.user.cid ~= 0  then
                    self.stu:getChild("box2_0","myRank"):setString(lang("juediyamen.unionrank",(self.proxy.jdyamen.user.crid)))
                else
                    self.stu:getChild("box2_0","myRank"):setString(lang("juediyamen.unionrank",lang("champion.nojoin")))
                end
                self.stu:getChild("box1","listView1"):setVisible(false)
                self.stu:getChild("box2","listView2"):setVisible(true)
                self.stu:getChild("box1","btnTotal"):setVisible(false)
                self.stu:getChild("box2","btnTotal"):setVisible(true)
            end
        end)
        tab:cut(1)
        return stu
    end

    function __Class:scheduleUpdateWithPriorityLua(node, callback, delaytime, priority)
        local frame = 0
        local time = os.time()
        frame = time
        priority = priority or 100000
        delaytime = delaytime or 1
        node:scheduleUpdateWithPriorityLua(function (dt)
            time = time + dt
            if time >= frame + delaytime then
                frame = frame + delaytime
                callback()
            end
        end, priority)
    end
    
    function __Class:initWidget()
        local function totalRank1( ... )
            self:command("JediYanmenCommand.showRank",1)
        end 
        local function totalRank2( ... )
            self:command("JediYanmenCommand.showRank",2)
        end 
        self.stu:addEvent("totalRank1", totalRank1)
        self.stu:addEvent("totalRank2", totalRank2)

        local function lunci( ... )
            self:command("JediYanmenCommand.showRank",3)
        end
        self.stu:getChild("lunci"):addClickEventListener(lunci)

        if self.activityProxy.openActivities[62] and self.activityProxy.openActivities[62][319] then
            local act = clone(self.activityProxy.openActivities[62][319])
            local sTime = lang("timeYMD",act.yueTime)
            local eTime = lang("timeYMD",act.eTime)
            self.stu:getChild("infoNode","actTime"):setString(sTime.."-"..eTime)
            local currTime = self.timeProxy:getTime()
            local count = tonumber(act.eTime) - currTime

            self.stu:getChild("infoNode","countTime"):setString("00:00:00")
            local serverArr = self.proxy.jdyamen.cfg.sever -- --------------
            -- dump(serverArr)
            local txt = ""
            for i,v in ipairs(serverArr) do
                if i == #serverArr then
                    txt = txt..v.sid.."服"
                else
                    txt = txt..v.sid.."服"..","
                end
            end
            
            local qufu =  self.stu:getChild("infoNode","listView","qufu")
            qufu:setString(txt)
            qufu:setContentSize(cc.size(qufu:getContentSize().width, 27 * math.ceil(#serverArr/6)))
            -- local function famatTime( ... )
            --     if count <= 0 then
            --         return
            --     end
            --     count = count - 1
            --     local count2 = os.date("%H:%M:%S",count)
            --     self.stu:getChild("infoNode","countTime"):setString(count2)
            -- end
            -- famatTime()
            -- self:scheduleUpdateWithPriorityLua(self.stu:getChild("infoNode","countTime"),function ( ... )
            --     famatTime()
            -- end)
        end
    end
    
    function __Class:initBox1(...)
        if self.stop1 then
            return 
        end
        self.stop1 = true
        self.scrollView1:removeAllChildren()
        -- local qixiServerData = self.zero:getProxy("game.activity.ActivityProxy").qixiServerData
        local dataArr  = self.proxy.jdyamen.cfg.rwd.my
        -- 获取总高度
        local totalHeight = 0
        for i, v in ipairs(dataArr) do
            local icon = ccui.ImageView:create()
            icon:loadTexture(UICommon.getDefaultIconUrl())
            local iconHeight = icon:getContentSize().height
            local maxLine = math.ceil(#v.member / 4)
            local itemHeight = 120 + maxLine * iconHeight + 20
            totalHeight = totalHeight + itemHeight
        end
        self.scrollView1:setInnerContainerSize({width = self.scrollView1:getContentSize().width, height = totalHeight})
        --
        self.listView1Height = 0
        for i, v in ipairs(dataArr) do
            local item = require("jediYanmen.jediSubItem.myRankItem").create()
            item.box:removeSelf(false)
            self:setItem1(item, v, totalHeight, i)
            self.scrollView1:addChild(item.box)
        end
    end
    
    -- item
    function __Class:setItem1(item, v, totalHeight, index)
        -- dump(v)
        local tmp = ccui.ImageView:create()
        tmp:loadTexture(UICommon.getDefaultIconUrl())
        local iconHeight = tmp:getContentSize().height
        --
        local width = item.box:getContentSize().width
        local maxLine = math.ceil(#v.member / 4)
        local itemHeight = 120 + maxLine * iconHeight + 10
        local startY = itemHeight - 60 * 2 - 10
        local startX = 60 * 2
        local offset = 10
        -- dump(v.member)
        for i, v in ipairs(v.member) do
            local row = math.floor((i - 1) / 4)
            local column = ((i - 1) % 4)
            local prop = self.universeProxy:getSomeByKindAndId(v.kind, v.id)

            local ThingIconUI = ThingIconUI:new(prop)
            local armature = ccs.Armature:create()
            armature:setScale(1.3)
            armature:init("frame")
            armature:getAnimation():playWithIndex(0,-1, 1)
            ThingIconUI.txt:setString(v.count)
            ThingIconUI:addChild(armature)
            ThingIconUI:setTouchEnabled(true)
             if v.kind ~= 2 then
                ThingIconUI:pickShow(self.zero,function ( ... )
                end)
            end
            ThingIconUI:setPosition(startX + (ThingIconUI.btn:getContentSize().width + 40) * column, startY - (ThingIconUI.btn:getContentSize().height + 10) * row - 10)
      
            item.box:addChild(ThingIconUI)
        end
        
        item.box:setContentSize(cc.size(width, itemHeight))
        item.box:setPositionY(totalHeight - self.listView1Height)
        UITools.getChild(item.box, "bg"):setContentSize(cc.size(width, itemHeight))
        UITools.getChild(item.box, "bg"):setPositionY(0)
        
        UITools.getChild(item.box, "black"):setPositionY(itemHeight - 10)
        
        if v.rand.rs ~= v.rand.re then
            UITools.getChild(item.box, "black", "title2"):setString(lang("crossyamen.rank", v.rand.rs) .. "~"..lang("crossyamen.rank", v.rand.re))
        else
            UITools.getChild(item.box, "black", "title2"):setString(lang("crossyamen.rank", UICommon.getChineseNum(v.rand.rs)))
        end
        
        self.listView1Height = self.listView1Height + itemHeight + offset
    end

    function __Class:initBox2(...)
        if self.stop2 then
            return 
        end
        self.stop2 = true
        self.listview2:removeAllChildren()
        
        -- local qixiServerData = self.zero:getProxy("game.activity.ActivityProxy").qixiServerData
        local dataArr  = self.proxy.jdyamen.cfg.rwd.club
        -- dump(dataArr)
         -- 获取总高度
        local totalHeight = 0
        local allRankItem = require("jediYanmen/jediSubItem/allRankItem")
        for i, v in ipairs(dataArr) do
            local item = allRankItem.create().box
            local iconHeight = item:getContentSize().height
            local maxLine = math.floor(#v.member / 5)
            local maxLine2 = math.floor(#v.mengzhu / 5)
            local itemHeight = 128 * (maxLine + maxLine2) + iconHeight + 20
            totalHeight = totalHeight + itemHeight
        end

        -- local itemHeight = require("jediYanmen/jediSubItem/allRankItem").create().box:getContentSize().height 
        -- local totalHeight = (itemHeight + 10) * #dataArr
        self.listview2:setInnerContainerSize({width = self.scrollView1:getContentSize().width, height = totalHeight})
        --
        self.listView1Height2 = 0

        -- self.listview2:removeAllItems()
        for i,v in ipairs(dataArr) do
            local item = allRankItem.create()
            self:setItem2(item.box,v,totalHeight, i, itemHeight)
            item.box:removeSelf(false)
            self.listview2:addChild(item.box)
        end

    end

    function __Class:numToChinese(num)
        local table = {"第一名","第二名","第三名"}
        return table[num]
    end

    function __Class:setItem2(item, v, totalHeight, index, itemHeight)
        item:setVisible(true)
        UITools.getChild(item,"mzt","Image_3","title2"):setVisible(v.rand.rs < 4)
        UITools.getChild(item,"mzt","Image_3","rank"):setVisible(v.rand.rs > 3)
        UITools.getChild(item,"mzt","Image_3","title2"):setString(self:numToChinese(v.rand.rs))
        UITools.getChild(item,"mzt","Image_3","rank","num1"):setString(v.rand.rs)
        UITools.getChild(item,"mzt","Image_3","rank","num2"):setString(v.rand.re)

        -- local tmp = ccui.ImageView:create()
        -- tmp:loadTexture(UICommon.getDefaultIconUrl())
        local size = item:getContentSize()
        local iconHeight = size.height
        --
        local width = item:getContentSize().width
        local maxLine = math.floor(#v.member / 5)
        local maxLine2 = math.floor(#v.mengzhu / 5)
        local itemHeight = 128 * (maxLine + maxLine2) +   iconHeight + 10
        local startY = itemHeight - 60 * 2 - 10
        local startX = 60 * 2
        local offset = 10

        local size = UITools.getChild(item,"bg"):getContentSize()
        UITools.getChild(item,"bg"):setContentSize(cc.size(size.width,itemHeight - 10))

        local itemList1 = UITools.getChild(item,"scrollView2")
        local itemList2 = UITools.getChild(item,"scrollView1")
        local itemsize = itemList1:getContentSize();
        itemList1:setContentSize(cc.size(itemsize.width,128 * (maxLine + 1)))

        local posy = itemList2:getPositionY()
        itemList2:setPositionY(posy + 128 * (maxLine))

        local posy = UITools.getChild(item,"mbt"):getPositionY()
        UITools.getChild(item,"mbt"):setPositionY(posy + 128 * (maxLine))

        for i,val in ipairs(v.member) do
            local prop = self.universeProxy:getSomeByKindAndId(val.kind, val.id)
            local ThingIconUI = ThingIconUI:new(prop)
            itemList1:addChild(ThingIconUI)

            local armature = ccs.Armature:create()
            armature:setScale(1.3)
            armature:init("frame")
            armature:getAnimation():playWithIndex(0,-1, 1)
            ThingIconUI:addChild(armature)
            ThingIconUI.txt:setString(val.count)
            ThingIconUI:setTouchEnabled(true)
             if val.kind ~= 2 then
                ThingIconUI:pickShow(self.zero,function ( ... )
                end)
            end
        end
        tools.layoutBox(itemList1,124,128)

        local itemsize = itemList2:getContentSize();
        itemList2:setContentSize(cc.size(itemsize.width,128 * (maxLine2 + 1)))

        local posy = UITools.getChild(item,"mzt"):getPositionY()
        UITools.getChild(item,"mzt"):setPositionY(posy + 128 * (maxLine + maxLine2))
        UITools.getChild(item,"Image_29"):setPositionY(posy + 128 * (maxLine + maxLine2)+40)

        for i,val in ipairs(v.mengzhu) do
            local prop = self.universeProxy:getSomeByKindAndId(val.kind, val.id)
            local ThingIconUI = ThingIconUI:new(prop)
            itemList2:addChild(ThingIconUI)

            local armature = ccs.Armature:create()
            armature:setScale(1.3)
            armature:init("frame")
            armature:getAnimation():playWithIndex(0,-1, 1)
            ThingIconUI:addChild(armature)
            ThingIconUI.txt:setString(val.count)
            ThingIconUI:setTouchEnabled(true)
            if val.kind ~= 2 then
                ThingIconUI:pickShow(self.zero,function ( ... )
                end)
            end
        end
        tools.layoutBox(itemList2,124,128)


        -- item:setContentSize(cc.size(width, itemHeight))
        item:setContentSize(cc.size(size.width,itemHeight))
        item:setPositionY(totalHeight - itemHeight -  self.listView1Height2)
        self.listView1Height2 = self.listView1Height2 + itemHeight + offset
    end

    
    function __Class:upListView(...)
        
    end
    
    function __Class:setItem(item, v)
        
    end
    
end
