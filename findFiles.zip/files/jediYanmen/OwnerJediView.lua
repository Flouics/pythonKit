local PanelUI = require("gameui.PanelUI")
local UITools = require("zeromvc.ui.UITools")
return function (__Class)
    
    function __Class:using(proxy)
        self.proxy = proxy;
        self.playerProxy = self.zero:getProxy("game.player.PlayerProxy")
        
        local stu = PanelUI:new("jediYanmen.ownerJediView")
        self.stu = stu;
        stu:offset(0, 0)
        self.listView = self.stu:getChild("listView")
        stu:addEvent("close", function()
            self:hideSelf()
            
        end)
        self.posX, self.posY = self.stu:getChild("imgNode"):getPosition()
        self.parm = 1
        self.stu:getChild("imgNode", "bgBtn"):setVisible(false)
        self:updateData()
        self:upListView()
        return stu
    end

    function __Class:updateData( ... )
        -- self.proxy.jdyamen.cfg.lun = 3
        self.lunshu = self.proxy.jdyamen.cfg.lun
        self:initWidget2()
        -- print("ssssssssssssssssssssssss",self.proxy.jdyamen.cfg.lun )
        self.paiming = 0
        self:setactTime()

        self.stu:getChild("comeCall"):addClickEventListener(function ( ... )
            self:command("JediYanmenCommand.showMesView", 6,1)
        end)

        -- local parm = 1
        local imgNode = self.stu:getChild("imgNode")
        local flagImg = self.stu:getChild("lookMore", "flagImg")
        -- local posX, posY = imgNode:getPosition()
        local function lookMore(...)
            imgNode:stopAllActions()
            self.stu:getChild("lookMore"):setTouchEnabled(false)
            local act1 = cc.MoveTo:create(0.2, cc.p(self.posX, self.posY + 1030))
            local act2 = cc.MoveTo:create(0.05, cc.p(self.posX, self.posY + 980))
            local act3 = cc.MoveTo:create(0.2, cc.p(self.posX, self.posY))
            local act4 = cc.MoveTo:create(0.05, cc.p(self.posX, self.posY + 1030))
            local function callfunc( ... )
                self.stu:getChild("lookMore"):setTouchEnabled(true)
                if self.parm == 2 then
                    self.stu:getChild("imgNode","bgBtn"):setVisible(true)
                end
            end 
            if self.parm == 1 then
                local seq1 = cc.Sequence:create(act1, act2,cc.CallFunc:create(callfunc))
                imgNode:runAction(seq1)
                flagImg:setScaleY(-1)
                self.parm = 2
            else
                local seq1 = cc.Sequence:create(act4, act3,cc.CallFunc:create(callfunc))
                imgNode:runAction(seq1)
                flagImg:setScaleY(1)
                self.stu:getChild("imgNode","bgBtn"):setVisible(false)
                self.parm = 1
            end
        end
        self.stu:getChild("imgNode","bgBtn"):addClickEventListener(lookMore)
        self.stu:getChild("lookMore"):addClickEventListener(lookMore)
    end

    function __Class:upTime_jdyamen( ... )
        self:setactTime()
    end
    
    function __Class:setactTime(...)
        local x1, y1, eTime = self:setCountTime()
        local state = self.proxy.jdyamen.cfg.state
        if y1 ~= -1 and state ~= 3 then
            self.stu:getChild( "time"):setVisible(true)
            self.stu:getChild( "time_0"):setVisible(true)
            self.stu:getChild( "time"):setString(x1)
        else
            self.stu:getChild( "time"):setVisible(false)
            self.stu:getChild( "time_0"):setVisible(false)
        end
        
    end

    function __Class:setpaimingParm(state, parm,paiming2 )
        if state == 3 then
            self:setRetchText("            "..lang("grave.endhd"),"","",self.stu:getChild("txt1"))
        else
            if parm == -2 then
                self.paiming  = paiming2
                self.stu:getChild( "time_0"):setString(lang("juediyamen.start",""))
                self:setRetchText("              "..lang("juediyamen.huodongweikai"),"","",self.stu:getChild("txt1"))
            elseif parm == -1 then
                self:setRetchText("            "..lang("juediyamen.actOver"),"","",self.stu:getChild("txt1"))
            else
                self.stu:getChild( "time_0"):setString(lang("juediyamen.taotaitime"))
                if self.paiming ~= paiming2 then
                    self.paiming = paiming2
                    self.stu:getChild("txt1"):removeAllChildren()
                    self:setRetchText(lang("juediyamen.taotaipaiming"),self.paiming,lang("juediyamen.yixiawanjia"),self.stu:getChild("txt1"))
                end
            end
        end
    end

     --倒计时
    function __Class:setCountTime(...)
        local time3
        self.activityProxy = self.zero:getProxy("game.activity.ActivityProxy")
        local str = ""
        local servarTime = self.timeProxy:getTime()
        local num,overtime = self.proxy:setCount()
        
        local paiming2,parm = self.proxy:setpaiming()
        local state = self.proxy.jdyamen.cfg.state
        self:setpaimingParm(state, parm,paiming2)

        local nowTime = overtime
        local eTime = 0
        
        local cd = {}
        cd["label"] = "qixitemp"
        cd["next"] = nowTime
        local nowTime = self.timeProxy:getLong(cd)
        time3 = nowTime > 0 and str..self.timeProxy:showTime(cd) or ""
        
        return time3, num, eTime
    end
    
    function __Class:initWidget()

        local myInfo = self.jediYanmenProxy.jdyamen.user

        self.stu:getChild("ninonInfo","clubRank"):setString(self.jediYanmenProxy.jdyamen.user.crid.."/"..#self.jediYanmenProxy.jdyamen.clublist)
        self.stu:getChild("ninonInfo","exist"):setString(self.club.sy.."/"..self.club.total)
        self.stu:getChild("union","name"):setString(self.club.cname)

        self.stu:getChild("ninonInfo","txt1_1"):setString("                                      ")
        self.stu:getChild("ninonInfo","txt1_2"):setString("                                      ")
        if self.club.sy == 0 then
            self.stu:getChild("ninonInfo","txt1"):setString(lang("juediyamen.areadlyFaild"))
            self.stu:getChild("ninonInfo","txt1_0"):setVisible(false)
        end
        self:setRetchText(lang("nationalDay.currRank"),myInfo.rid,"名",self.stu:getChild("ninonInfo","txt1_1"))
        self:setRetchText(lang("nationalDay.currRank2"),self.jediYanmenProxy.jdyamen.user.crid,"名",self.stu:getChild("ninonInfo","txt1_2"))
    end

    function __Class:setRetchText( txt,txt2,txt3, item)
        local rtes = {}
        table.insert(rtes, UICommon.RET(txt,24, cc.c3b(255,255,255)) )
        table.insert(rtes, UICommon.RET(txt2,24, cc.c3b(0,255,0)) )
        table.insert(rtes, UICommon.RET(txt3,24, cc.c3b(255,255,255)) )
        UICommon.createRichText(item, rtes)
        -- item:setString("")
    end

    function __Class:upListView( ... )
   
        self.clubInfo = clone(self.jediYanmenProxy.jdyamen.clubInfo)
        table.sort(self.clubInfo,function ( a,b )
            return tonumber(a.rid) < tonumber(b.rid)
        end)

        self.club = self.args[1]
        self.club2 = self.clubInfo[1]

        self.unionProxy = self.zero:getProxy("game.union.UnionProxy")
        local index = 1
        for k,v in ipairs(self.clubInfo) do
            v.id = index 
            index= index + 1
            v.postName = self.unionProxy:getPosition(v.post)
            for i,val in ipairs(self.jediYanmenProxy.jdyamen.userList) do
                if val.u == v.u.uid then
                    v.u.name = val.n
                    break
                end
            end
        end

        local itemName = "jediYanmen.jediSubItem.ownerJediItem"
        local function getItem(v)
            local stu = require(itemName).create()
            local item=stu.box
            -- local posx = item:getChildByName("qufuNumber"):getPositionX()
            -- item:getChildByName("qufuNumber"):setPositionX(posx + 230)
            item:removeSelf(true)
            item.setData=function (_item,v)
                self:setItem4(item,v)
            end
            return item
        end
        local TestItem = require(itemName).create()
        self.listView:plus(TestItem.box:getContentSize(),getItem)
        self.listView:upList(self.clubInfo )
        self:initWidget()
    end

    function __Class:setItem4( item,v )
        local titleNode = UITools.getChild(item,"titleNode")
        local bg = UITools.getChild(item,"bg")
        -- local bg = UITools.getChild(item,"bg")
        local rank = UITools.getChild(titleNode,"rank")
        local chenyuan = UITools.getChild(titleNode,"chenyuan")
        local zhiwei = UITools.getChild(titleNode,"zhiwei")
        local score = UITools.getChild(titleNode,"score")

        rank:setString(v.rid)
        chenyuan:setString(v.u.name)
        zhiwei:setString(v.postName)
        score:setString(v.score)
        if tonumber(v.id) % 2 == 0 then
            bg:setVisible(false)
        else
            bg:setVisible(true)
        end

        local color = self.proxy:getClolor(v.u.uid,v.rid,1,self.club.sy,v.id)
        rank:setTextColor(color)
        chenyuan:setTextColor(color)
        zhiwei:setTextColor(color)
        score:setTextColor(color)

    end

    function __Class:upView()
        
        self.listinfo = clone(self.proxy.kill20log)
        -- dump(self.listinfo)
        local userList = clone(self.proxy.jdyamen.userList)
        -- self.yamenProxy = self.zero:getProxy("game.yamen.YamenProxy")
        -- local listinfo = self.yamenProxy.kill20log
        local moreItem =  require("jediYanmen/jediSubItem/showLogItem")
        for i,v in ipairs(self.listinfo) do
            v.user = {}
            v.fuser = {}
            for k,j in ipairs(userList) do
                if j.u == v.uid then
                    v.user.name = j.n
                    v.user.uid = j.u
                    v.user.cid = j.c
                end
                if j.u == v.fuid then
                    v.fuser.name = j.n
                    v.fuser.uid = j.u
                    v.fuser.cid = j.c
                end
            end
        end
        -----------------列表---------------------
        local function getItem(v)
            local stu = moreItem.create()
            local item=stu.box
            item:removeSelf()
            item.setData=function (_item,v)
                self:setItem2(item,v)
            end
            return item
        end
        local TestItem = moreItem.create()
        self.ListView2:plus(TestItem.box:getContentSize(),getItem)
        self.ListView2:upList(self.listinfo)
        -----------------列表---------------------
        local isCanGetMes = true
        local function scrollViewEvent(sender, evenType)
            sender:scrollHd(evenType)
            if evenType ==  ccui.ScrollviewEventType.scrollToBottom then
                isCanGetMes = true
            elseif evenType == ccui.ScrollviewEventType.bounceBottom then
                local height = sender:getInnerContainerSize().height
                if isCanGetMes and sender:getInnerContainerPosition().y > 100 then
                    local lastLog = self.proxy.lastKillLog
                    if lastLog.id and lastLog.id > 0 then
                        self:command("JediYanmenCommand.getMoreHistory",lastLog.id,3)
                    end
                    isCanGetMes = false
                end
            end
        end
        self.ListView2:addScrollViewEventListener(scrollViewEvent)
    end
    function __Class:setItem2(item,v)
        UITools.getChild(item,"bg","rbg","rText"):setString(v.index)
        UITools.getChild(item,"bg","nameText"):setString(v.user.name)

        local noText = UITools.getChild(item,"bg","nameText","uidTxt")
        noText:setString("("..lang("rank.no",v.user.uid)..")")
        noText:setPositionX(UITools.getChild(item,"bg","nameText"):getContentSize().width+30)

        if self.proxy.jdyamen.user and  v.user.cid == self.proxy.jdyamen.user.cid then
            UITools.getChild(item,"bg","nameText"):setTextColor(cc.c3b(0,255,0))
        else
            UITools.getChild(item,"bg","nameText"):setTextColor(cc.c3b(255,0,0))
        end
        -- dump(v.user.chenghao)   
        local chenghao = UITools.getChild(item,"bg","nameText","titleImg")
        -- chenghao:ignoreContentAdaptWithSize(true)
        chenghao:setVisible(false)

        -- chenghao:setVisible(UICommon.getIsShowChengHao(v.user.chenghao))
        -- UICommon.loadExternalTexture(chenghao,UICommon.getUserTitle1IconUrl(v.user.chenghao))

        -- chenghao:setPositionX(noText:getPositionX() + noText:getContentSize().width + chenghao:getContentSize().width*0.5)    
        --衙门界面 皇帝特效
        local effect = item:getChildByTag(70)
        -- if v.user.chenghao == 22 or v.user.chenghao == 29 then 
        --     effect:setVisible(true)
        -- else
        --     effect:setVisible(false)
        -- end
        local servantProxy = self.zero:getProxy("game.servant.ServantProxy")
        local servant = servantProxy:getHeroById(v.hid)
        UITools.getChild(item,"bg","timeText"):setString(lang("mail.time")..tools.getTime(v.ktime))
         local rtes = {}
        if v.ftype == 0 and v.win == 0 then
            table.insert(rtes, UICommon.RET(lang("yamen.mt1",servant.name),26, cc.c3b(255,255,255)))
        elseif v.ftype == 0 and v.win == 1 then
            table.insert(rtes, UICommon.RET(lang("yamen.mt2",servant.name),26, cc.c3b(255,255,255)))
        elseif v.ftype == 1 and v.win == 1 then
            table.insert(rtes, UICommon.RET(lang("yamen.mt3",servant.name),26, cc.c3b(255,255,255)))
        elseif v.ftype == 1 and v.win == 0 then
            table.insert(rtes, UICommon.RET(lang("yamen.mt4",servant.name),26, cc.c3b(255,255,255)))
        end
        table.insert(rtes, UICommon.RET(v.fuser.name,26, cc.c3b(0,255,0)))
        table.insert(rtes, UICommon.RET(lang("yamen.mt5",v.kill),26, cc.c3b(255,255,255)))
        if v.dkill >= 3 then
            -- 完成了X连杀
            table.insert(rtes, UICommon.RET(lang("yamen.mt8",v.dkill),26, cc.c3b(0,255,0)))
        end

        if v.ftype == 1 then
            table.insert(rtes, UICommon.RET(lang("yamen.mt6"),26, cc.c3b(255,255,255)))
        end
        UICommon.createRichText(UITools.getChild(item,"bg","Panel"), rtes)
        if v.user.cid == self.proxy.jdyamen.user.cid then
            UITools.getChild(item,"btn"):setVisible(false)
        else
            UITools.getChild(item,"btn"):setVisible(true)
            if self.proxy:isChallenged(v.id) then
                UITools.getChild(item,"btn"):setTouchEnabled(false)
                UITools.getChild(item,"btn"):setBright(false)
                UITools.getChild(item,"btn","btnName"):enableOutline({r = 0, g = 31, b = 87, a = UICommon.toNumber("alpha1",0)}, 2)
                UITools.getChild(item,"btn","btnName"):setString(lang("yamen.challenged"))
            else
                UITools.getChild(item,"btn"):setTouchEnabled(true)
                UITools.getChild(item,"btn"):setBright(true)
                UITools.getChild(item,"btn","btnName"):enableOutline({r = 0, g = 31, b = 87, a = 255}, 2)
                UITools.getChild(item,"btn","btnName"):setString(lang("more.tiaozhan"))
                UITools.getChild(item,"btn"):addClickEventListener(function(sender)
                    self:command("JediYanmenCommand.showServantView",v.user.uid,"tiaozhan",v.id)
                end)
            end
        end
    end
    function __Class:initWidget2()
        self.ListView2 = self.stu:getChild("imgNode","ListView")
        self.ListView2:setBounceEnabled(true)
        -- UICommon.repeatUpAndDown(self.stu:getChild("box","jtImg"),0.8,8)
        -- self.stu:getChild("box"):moveTo({y=display.height,time = 0.15})
        self:upView()
        self:upKill()
    end

    function __Class:upKill()
        local info = self.listinfo[1]
        -- dump(info)
        if info == nil then return end
        local servantProxy = self.zero:getProxy("game.servant.ServantProxy")
        local servant = servantProxy:getHeroById(info.hid)
        local rtes = {}
        if info.ftype == 0 and info.win == 0 then
            table.insert(rtes, UICommon.RET(lang("yamen.mt1",servant.name),26, cc.c3b(255,255,255)))
        elseif info.ftype == 0 and info.win == 1 then
            table.insert(rtes, UICommon.RET(lang("yamen.mt2",servant.name),26, cc.c3b(255,255,255)))
        elseif info.ftype == 1 and info.win == 1 then
            table.insert(rtes, UICommon.RET(lang("yamen.mt3",servant.name),26, cc.c3b(255,255,255)))
        elseif info.ftype == 1 and info.win == 0 then
            table.insert(rtes, UICommon.RET(lang("yamen.mt4",servant.name),26, cc.c3b(255,255,255)))
        end
        table.insert(rtes, UICommon.RET(info.fuser.name,26, cc.c3b(0,255,0)))
        table.insert(rtes, UICommon.RET(lang("yamen.mt5",info.kill),26, cc.c3b(255,255,255)))
        if info.ftype == 1 then
            table.insert(rtes, UICommon.RET(lang("yamen.mt6"),26, cc.c3b(255,255,255)))
        end
        table.insert(rtes, UICommon.RET("...",26, cc.c3b(255,255,255)))
        -- if info.lkill >= 3 then
        --     table.insert(rtes, UICommon.RET(lang("yamen.mt7",info.lkill),24, cc.c3b(255,0,0)))
        -- end
        self.bpanel = self.stu:getChild("lookMore","Panel")
        UICommon.createRichText(self.bpanel, rtes)
        self.stu:getChild("lookMore","nameText"):setString(info.user.name.."("..lang("set.id",info.user.uid)..")")
    end

    function __Class:upKilllog20( ... )
        self:initWidget2()
    end
    
end
