local PanelUI=require("gameui.PanelUI")
local UITools = require("zeromvc.ui.UITools")
local RichLabel=require "game.friend.richlabel.RichLabel"
return function (__Class)
function __Class:using(yamenProxy)
    self.yamenProxy = yamenProxy
    local stu=PanelUI:new("yamen.oneKeyFailed",true)
    stu:offset(display.cx,display.cy)
    self.stu=stu
    --失败音效
    self.zero:command("game.yamen.fightF")

    local function closeHd()
        self:command("JediYanmenCommand.oneKeyOver")
        self:hideSelf()
    end
    stu.bg:addEvent("HIT",closeHd)
    self:initWidget()
    return stu
end

function __Class:initWidget()
    local info = self.yamenProxy.oneKeyInfo
    local hid = self.yamenProxy.win.over.hid
    local servantProxy = self.zero:getProxy("game.servant.ServantProxy")
    local universeProxy= self.zero:getProxy("game.universe.UniverseProxy")
    local item = universeProxy:getSomeByKindAndId(1,123)-- 出使令
    local cnt = {}
    for i,v in ipairs(info.items) do
        if v.id == 9 and v.kind == 2 then           -- 衙门分数
            cnt[1] = v.count
        elseif v.kind == 5 then                     -- 书籍经验
            cnt[2] = v.count
        elseif v.kind == 6 then                     -- 技能经验
            cnt[3] = v.count
        elseif v.id == 6 and v.kind == 2 then       -- 衙门精力
            cnt[4] = v.count
        elseif v.id == 123 and v.kind == 1 then     -- 出使令
            cnt[5] = v.count
        end
    end
    local hero = servantProxy:getHeroById(hid)
    local n = {}
    local txt = {}
    for i=1,5 do
        n[i] = self.stu:getChild("n"..i)
        txt[i] = RichLabel.new {fontName = UICommon.getTTFName(),fontSize = 24,}
    end
    local tip = lang("yamen.mt1",hero.name)
    if info.ftype == 0 and info.win == 0 then -- 击败
        tip = lang("yamen.mt1",hero.name)
    elseif info.ftype == 0 and info.win == 1 then -- 全歼
        tip = lang("yamen.mt2",hero.name)
    elseif info.ftype == 1 and info.win == 1 then -- 追捕全歼
        tip = lang("yamen.mt3",hero.name)
    elseif info.ftype == 1 and info.win == 0 then -- 追捕
        tip = lang("yamen.mt4",hero.name)
    end
    txt[1]:setString(UICommon.formatRichText(lang("yamen.Tip1",tip,info.kill)))
    txt[2]:setString(UICommon.formatRichText(lang("yamen.Tip5",cnt[1] or 0)))
    txt[3]:setString(UICommon.formatRichText(lang("yamen.Tip3",cnt[2] or 0)))
    txt[4]:setString(UICommon.formatRichText(lang("yamen.Tip4",cnt[3] or 0)))
    txt[5]:setString(UICommon.formatRichText("#F+".. (cnt[4] or 0)))
    txt[1]:setAnchorPoint(0.5,0.5)
    for i=1,5 do
        n[i]:addChild(txt[i])
    end
    
end
end