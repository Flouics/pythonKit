local PanelUI = require("gameui.PanelUI")
local UITools = require("zeromvc.ui.UITools")
return function (__Class)
    
    function __Class:using(proxy)
        self.proxy = proxy;
        self.playerProxy = self.zero:getProxy("game.player.PlayerProxy")
        
        local stu = PanelUI:new("jediYanmen.theirJediView")
        self.stu = stu;
        stu:offset(0, 0)
        self.listView = self.stu:getChild("listView")
        stu:addEvent("close", function()
            self:hideSelf()
            
        end)
        
        self:initWidget()
        self:upListView()
        return stu
    end
    
    function __Class:initWidget()

    end

    function __Class:upListView( ... )
        local arr2 = {{index = 1},{index = 2},{index = 3},{index = 4},{index = 5},{index = 6},{index = 7},{index = 8}}
   
        local itemName = "jediYanmen.jediSubItem.ownerJediItem"
        local function getItem(v)
        local stu = require(itemName).create()
        local item=stu.box
        -- local posx = item:getChildByName("qufuNumber"):getPositionX()
        -- item:getChildByName("qufuNumber"):setPositionX(posx + 230)
        item:removeSelf(true)
        item.setData=function (_item,v)
            self:setItem(item,v)
        end
        return item
    end
    local TestItem = require(itemName).create()
    self.listView:plus(TestItem.box:getContentSize(),getItem)
    self.listView:upList(arr2 )

    end

  
    function __Class:setItem( item,v )
        print("sssssssssssssssssssss",v.index)
    end
    
end
