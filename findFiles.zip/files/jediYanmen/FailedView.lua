local PanelUI=require("gameui.PanelUI")
local UITools = require("zeromvc.ui.UITools")

return function (__Class)
function __Class:using(yamenProxy)
    self.yamenProxy = yamenProxy
    local stu=PanelUI:new("yamen.failedView",true)
    stu:offset(display.cx,display.cy)
    self.stu=stu
    --失败音效
    self.zero:command("game.yamen.fightF")

    local function closeHd()
        self:command("JediYanmenCommand.checkPopup")
        self:hideSelf()
    end
    stu.bg:addEvent("HIT",closeHd)
    self:initWidget()
    return stu
end

function __Class:initWidget()
    local info = self.yamenProxy.win.fight
    self.stu:getChild("Image_31","val"):setString(info.items[1].count)
end
end