-- 个人排名
local UITools = require("zeromvc.ui.UITools")
local PanelUI = require("gameui.PanelUI")
return function (__Class)
    
    function __Class:using(JediYanmenProxy, timeProxy)
        self.timeProxy = timeProxy
        self.jediYanmenProxy = JediYanmenProxy
        self.playerProxy = self.zero:getProxy("game.player.PlayerProxy")
        local stu = PanelUI:new("jediYanmen.jediChallengeView",true)
        self.stu = stu
        
        stu:addEvent("close", function(...)
            self:hideSelf()
        end)
        self:initView()
        return stu
    end
    
    function __Class:initView(...)
        self.clubAllList = clone(self.jediYanmenProxy.clubAllList)
        self:initListView()
    end
    
    -- 活动商城
    function __Class:initListView(type)
        
        self.listView = self.stu:getChild("listView5")
      
        -- self.data = self.jediYanmenProxy.jdyamen.clubInfo
        -- self.club = self.clubAllList[tonumber(self.args[1])]
        self.club = self.args[1]
        self.clubInfo = clone(self.jediYanmenProxy.jdyamen.clubInfo)

        local index = 0

        -- local allUserList = clone(self.jediYanmenProxy.allUserList)
        -- table.sort(self.data,function ( a,b )
        --     local rid1,rid2
        --     for i,v in ipairs(allUserList) do
        --         if v.uid == a.u.uid then
        --             rid1 = v.rid
        --             a.score = v.score
        --         end
        --         if v.uid == b.u.uid then
        --             rid2 = v.rid
        --             b.score = v.score
        --         end
        --     end
        --     if not rid1 or not rid2 then
        --         return false
        --     end
        --     return rid1 < rid2
        -- end)
        for i,v in ipairs(self.clubInfo) do
            index = index + 1
            v.index = index
             for i,val in ipairs(self.jediYanmenProxy.jdyamen.userList) do
                if val.u == v.u.uid then
                    v.u.name = val.n
                    break
                end
            end
        end
        -- dump(self.data)
        --
        local itemName = "jediYanmen/jediSubItem/challengeIten"
        local function getItem(v)
            local stu = require(itemName).create()
            local item = stu.box
        
            item:removeSelf()
            item.setData = function (_item, v)
                self:setItem(item, v)
            end
            return item
        end
        local TestItem = require(itemName).create()
        self.listView:plus(cc.size(580,200), getItem)
        self.listView:upList(self.clubInfo)
        self.listView:setClippingType(1)
        self.listView:setBounceEnabled(true)
        -- self.listView:setClippingEnabled(false)
    end
    
    function __Class:setItem(item, v)
        UITools.getChild(item,"imgHeadBg"):removeAllChildren()
        UITools.getChild(item,"name"):setString(v.u.name)
        UITools.getChild(item,"rank"):setString(v.rid)
        UITools.getChild(item,"score"):setString(v.score)
        local icon = UITools.getChild(item,"imgHeadBg")
        local conf=self.playerProxy:getUserFrameConf(v.u.frame)
        UICommon.loadExternalTexture(icon,UICommon.getUserFrame(conf.icon))
        icon:ignoreContentAdaptWithSize(true)

        if  v.u.level < 18 then
            UICommon.addLightHeadImg(icon,v.u)
        else
           UICommon.addHeadImg(icon,v.u)
        end
        if UITools.getChild(item,"imgHeadBg").armature then
            UITools.getChild(item,"imgHeadBg").armature:removeSelf()
        end
        UITools.getChild(item,"btn1"):addClickEventListener(function ( ... ) --挑战
            -- self:command("JediYanmenCommand.challengeOne",v.u.uid)
            self.zero:show("game.jediYanmen.ServantView",v.u.uid,"tiaozhan",v.id)
        end)

        UITools.getChild(item,"btn2"):addClickEventListener(function ( ... )--追捕
            self.zero:show("game.jediYanmen.ServantView",v.u.uid,"zhuisha",v.id)
        end)

        if v.index > self.club.sy then
            UITools.getChild(item,"btn1"):setVisible(false)
            UITools.getChild(item,"btn2"):setVisible(false)
        else
            UITools.getChild(item,"btn1"):setVisible(true)
            UITools.getChild(item,"btn2"):setVisible(true)
        end
   
    end
    function __Class:closejediChallenge()
        self:hideSelf()
    end
    
end
