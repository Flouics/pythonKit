local zeromvc = require "zeromvc.zeromvc"
local __Class = zeromvc.classProxy(...)

function __Class:init()
    self.timeProxy = self.zero:getProxy("game.time.TimeProxy")
	 -- 聊天消息
    self.chatMes = {}
    -- 备份的聊天消息
    self.ser_chatMes = {}
    -- 禁言消息
    self.limitMes = {}

    self.clubAllList = {} --所有参赛人员信息

    self.jdyamen = {} -- 
    self.jdyamen.cfg = {}
    self.jdyamen.scorelist = {}
    self.jdyamen.dielist = {}
    self.jdyamen.clubRankList = {}
    self.jdyamen.clist = {}
    self.jdyamen.enymsg = {}
    self.jdyamen.chat = {}
    self.jdyamen.zhuisha = {}
    self.jdyamen.cslist = {}
    self.jdyamen.deflog = {}
    self.jdyamen.user = {}
    self.jdyamen.win = {}
    self.jdyamen.fight = {}
    self.jdyamen.onekey = {}
    self.jdyamen.info = {}
    self.jdyamen.clublist = {}
    self.jdyamen.userList = {}
    self.lastKillLog = {}
    self.oneKeyInfo = {}
    self.kill20log = {}
    self.fclist = {}
    self.challengedList = {}
    self.deflog = {}
    self.enymsg = {}
    self.zhuisha = {}
    self.lastEnymsg = {}
    self.enymsg = {}
    self.lastDeflog = {}
    self.seletid = 0
    self.serchJDRecordData = {list={},time=0}
end

function __Class:getClub( cid ) -- 帮会信息
    local clubList = self.clubAllList
    local club = clubList[tonumber(cid)]
    return club
end

function __Class:getMember( club,uid ) -- 帮会成员信息
    local member = club.member[tonumber(uid)]
    return member
end

function __Class:getJDRecords(uid)
    self.serchJDRecordData=json.decode(cc.UserDefault:getInstance():getStringForKey("yamenRecordJD")) or self.serchJDRecordData
    local info=self.serchJDRecordData.list[tostring(uid)]
    return info or {} 
end

function __Class:setClubInfo(vo)
    local arr = {}
    
    for i, v in ipairs(vo) do
        arr[v.cid] = v
        arr[v.cid].member = {}
        for k, j in ipairs(self.jdyamen.userList) do
            if j.c == v.cid then
                arr[v.cid].member[j.u] = j
                arr[v.cid].member[j.u].score = 0
            end
        end
    end
    self.clubAllList = arr
        
 end

function __Class:setClubInfos( vo )
    for i,v in ipairs(vo) do
        if self.clubAllList[v.cid] then
            for k,j in ipairs(self.clubAllList[v.cid].member) do
                if j then
                    j.score = tonumber(v.score)
                end
            end
            table.sort( self.clubAllList[v.cid].member, function ( a,b )
                return a.score > b.score
            end )
        end
    end
end

-- 获取最新的聊天消息
function __Class:getNewestMes()
    local len = #self.chatMes
    if len > 0 then
        return self.chatMes[len]
    end
end

-- 创建 消息
function __Class:createChatMes(msg)
    local playerProxy = self.zero:getProxy("game.player.PlayerProxy")
    local time = self.timeProxy:getTime()        
    local mes= {}
    local vo = {}
    vo[1] = mes

    mes["id"] = -1
    mes["msg"] = msg
    mes["time"] = time

    mes["isGM"] = 0
    mes["type"] = 1
    mes["user"] = {}
    mes["user"]["chenghao"] = playerProxy.user.chenghao
    mes["user"]["job"] = playerProxy.user.job
    mes["user"]["level"] = playerProxy.user.level
    mes["user"]["name"] = playerProxy.user.name
    mes["user"]["sex"] = playerProxy.user.sex
    mes["user"]["uid"] = playerProxy.user.uid
    mes["user"]["vip"] = playerProxy.user.vip
    return mes
end

function __Class:loadChat(vo)
    self.chatMes = self:load(self.chatMes,self.limitMes,vo)
    self.ser_chatMes = clone(self.chatMes)

    table.sort(self.ser_chatMes,function (a,b)
        return a.nid < b.nid
    end)

    -- 测试
    -- for i,v in ipairs(self.ser_chatMes) do
        -- print(v.id,v.nid,v.msg)
    -- end
end

-- 与禁言消息一起 重排 服务端数据
function __Class:load(list,limitList,vo)
    local len = #list
    list = {}

    -- 编号排序 服务端数据
    for i,v in ipairs(vo) do
        v["nid"] = v.id
        table.insert(list,v)
    end
    -- dump(list)

    table.sort(list,function (a,b) -- 升序
        return a.nid < b.nid
    end)

    if len > 0 then
        -- 插入 禁言信息 到 原始列表        
        for k1,v1 in pairs(limitList) do
            for i2,v2 in ipairs(list) do
                if v2.id == k1 then
                    for i3,v3 in ipairs(v1) do
                        -- print(i2,i3,i2+i3)
                        table.insert(list,i2+i3,v3)
                    end

                    break 
                end
            end        
        end

        -- 处理 禁言的特殊情况：当禁言用户全服第一次发言
        if limitList[0] ~= nil then
            self:frontInsert(list,limitList[0])
        end

        -- 重新定号
        local nid = list[1].id
        -- dump(nid)
        for k,v in pairs(list) do
            v["nid"] = nid
            nid = nid + 1
        end  
    end
    -- dump(list)
    return list
end

function __Class:addLimitChat(list,limitList,vo)
    table.insert(list,vo)
    -- 重新定号
    local nid = list[1].id
    -- dump(nid)
    for k,v in pairs(list) do
        v["nid"] = nid
        nid = nid + 1
    end

    -- dump(list)
    -- 添加禁言信息
    -- 找到最近的禁言归属
    local lastestId = 0
    local len = #list
    if len > 0 then
        for i=0,20 do
            local tmp1 = list[len-i]
            if tmp1 ~=nil then
                local tmp  = list[len-i].id
                if tmp ~= -1 then
                    lastestId = tmp
                    break
                end
            end
        end
    end

    dump(lastestId)
    if limitList[lastestId] == nil then
        limitList[lastestId] = {}
    end
    table.insert(limitList[lastestId],vo)
end

-- 前插入：addedList添加到list前
function __Class:frontInsert(list,addedList)
    local index = 1
    for i,v in ipairs(addedList) do
        if index == 1 then
            table.insert(list,1,v)
        else
            table.insert(list,index,v)
        end
        index = index + 1
    end
end

-- 在黑名单有变动时，重新加载消息
function __Class:reloadMes(blackList)
    -- dump(blackList,"reloadMes")
    self.chatMes = clone(self.ser_chatMes)
    -- dump(self.chatMes)
    self:dealMes(blackList)
    self:update("updateChat")
end

function __Class:dealMes(blackList)
    -- self:getFrontMes()
    self:removeMesWithBl(blackList)
end

-- 获取 跨服聊天前20条
function __Class:getFrontMes()
    if self.chatMes ~= nil then
        local tempCrossMes = {}
        local from = #self.chatMes > 20 and #self.chatMes - 19 or 1
        local to = #self.chatMes
        for i = from, to do
            table.insert(tempCrossMes,self.chatMes[i])
        end
        self.chatMes = tempCrossMes
    end
end

--移除黑名单里面的人物聊天的信息
function __Class:removeMesWithBl(blackList)
    if blackList == nil then
        return
    end

    if self.chatMes then
        local hasList={}
        for i,v in ipairs(blackList) do
            for pi,pv in ipairs(self.chatMes) do
                if v.id == pv.user.uid then
                    table.insert(hasList,pv);
                end
            end
        end
        for i,v in ipairs(hasList) do
            table.removebyvalue(self.chatMes, v)
        end
    end
end

function __Class:loadFight(vo)
    self.fight = vo
    -- dump(vo)
    local flag = false
    for i,v in ipairs(vo.shop) do
        if v.type == 1 then flag = true end
        table.merge(v,self:getYamenShopById(v.id))
        v.buyTypeIcon = UICommon.getResIconUrl(v.need.id)
        v.icon = UICommon.getYamenSkillUrl(v.icon)
    end
    self.fight.shop.isBuy = flag
    self:update("upChooseView")
end

function __Class:getYamenShopById(id)
    return self:getConf("yamenShop","id",id)
end

function __Class:loadWin(vo)
    self.win = vo
    if self.win.rwd and next(self.win.rwd)~=nil and self.seletid ~= 1 then
        local t = self.win.rwd.jiade[1]
        self.win.rwd.jiade[1] = self.win.rwd.jiade[self.seletid]
        self.win.rwd.jiade[self.seletid] = t
    end

    --战斗改前端计算
    local fight = vo.fight
    
    if next(fight.log) == nil then
        local yamenProxy = self.zero:getProxy("game.yamen.YamenProxy")
        self.win.fight.log = yamenProxy:getFightLog(fight.fightinfo,fight.first,fight.winer,fight)
    end
end

function __Class:getPVPTextById(id)
    return self:getConf("pvpText","id",id)
end

function __Class:loadFclist(vo)
    self.fclist = {}
    for i,v in ipairs(vo) do
        self.fclist[v.id] = v
    end
end

function __Class:isChallenged(id)
    for i,v in ipairs(self.challengedList) do
        if id == v.id then
            return true
        end
    end
    return false
end

function __Class:istaotai( uid ) --是否被淘汰
    for i,v in ipairs(self.dielist) do
        if uid == v.uid then
            return true
        end
    end
    return false
end

function __Class:loadEnymsg(vo)
    self.enymsg = {}
    table.sort(vo,function(a,b)
          return a.time > b.time
    end)
    for i,v in ipairs(vo) do
        v.index = i
        table.insert(self.enymsg,v)
    end
    self.lastEnymsg = self.enymsg[#self.enymsg]
end

function __Class:loadKill20log(vo)
    self.kill20log = {}
    table.sort(vo,function ( a,b )
        return a.ktime > b.ktime
    end)
    for i,v in ipairs(vo) do
        v.index = i
        table.insert(self.kill20log,v)
    end
    self.lastKillLog = self.kill20log[#self.kill20log]
end

function __Class:loadDeflog(vo)
    self.deflog = {}
    table.sort(vo,function(a,b)
          return a.dtime > b.dtime
    end)
    for i,v in ipairs(vo) do
        v.index = i
        table.insert(self.deflog,v)
    end
    self.lastDeflog = self.deflog[#self.deflog]
end

function __Class:isHaveZigeChallenge( parm )
    local h,m,s = self:getTime()
    local user = self.jdyamen.user
    local info = self.jdyamen.info
    if user.qualify == 0 and not parm then
        self.zero:command(GameKey.TIP,lang("juediyamen.notqualification"))
        return true   ---
    end
    if user.win == 0 and not parm then
        self.zero:command(GameKey.TIP,lang("juediyamen.alreadyOut"))
        return true
    end
    if self.jdyamen.cfg.zd_state == 0 then
        self.zero:command(GameKey.TIP,lang("juediyamen.huodongweikai"))
        return true
    end
    return false
end

function __Class:setpaiming( h )
    local paiming2,parm
    self.lunshu = self.jdyamen.cfg.lun
    if not self.lunshu or not next(self.jdyamen.cfg.lunshu) or self.lunshu == 0 then
        return 1,0
    end
    paiming2 = self.jdyamen.cfg.lunshu[self.lunshu].num
    if self.lunshu then
        if self.jdyamen.cfg.zd_state == 0 then
            parm = -2 
        elseif self.jdyamen.cfg.zd_state == 1 then
            parm = 1
        else
            parm = -1
        end
    else
        parm = -1
    end

    return paiming2,parm
end

function __Class:getClubRank( ... )  -- 帮会排名
    local clubRankList = clone(self.jdyamen.clubRankList)
    for i,v in ipairs(clubRankList) do
        if tonumber(v.cid) == tonumber(self.jdyamen.user.cid) then
            return v.rid
        end
    end
    return ""
end

function __Class:getClubScore( ... )  -- 帮会分数
    local clubRankList = clone(self.jdyamen.clubRankList)
    for i,v in ipairs(clubRankList) do
        if tonumber(v.cid) == tonumber(self.jdyamen.user.cid) then
            return v.score
        end
    end
    return ""
end

function __Class:getScore( uid )  -- 获取个人分数
    local allUserList = clone(self.allUserList)
    for i,v in ipairs(allUserList) do
        if tonumber(v.uid) == tonumber(uid) then
            return v.score
        end
    end
    return ""
end

function __Class:getislive( uid )  -- 获取个是否活着
    local scorelist = clone(self.jdyamen.scorelist)
    for i,v in ipairs(scorelist) do
        if tonumber(v.uid) == tonumber(uid) then
            return true
        end
    end
    return false
end

function __Class:getClolor( uid ,rid, type1 , liveNum,index)
    local rgb1 --安全
    local rgb2--在淘汰名外
    local rgb3--已淘汰
    if type1 == 1 then
        rgb1 = cc.c3b(0,255,0) --安全
        rgb2 = cc.c3b(255,0,0) --在淘汰名外
        rgb3 = cc.c3b(255,255,255) --已淘汰
    else
        rgb1 = cc.c3b(0,255,0) --安全
        rgb2 = cc.c3b(255,0,0) --在淘汰名外
        rgb3 = cc.c3b(255,255,255) --已淘汰
    end
    local servarTime = self.timeProxy:getTime()
    local state = self.jdyamen.cfg.state
    local h = self:setHour(servarTime)
    if  index <= liveNum then
        if state ~= 3 and  rid > self:setpaiming(h) then
            return rgb2
        end
        return rgb1
    else
        return rgb3
    end
end

function __Class:getName( uid )  -- 获取名字
    for i,v in ipairs(self.jdyamen.userList) do
        if v.u == uid then
            return v.n
        end
    end
    return ""
end

function __Class:setHour( servarTime )
    local m = tonumber(os.date("%M", servarTime))
    local h = math.floor(tonumber(os.date("%H", servarTime)) + UICommon.setTimeOffset()) + (os.date("*t", servarTime).isdst and -1 or 0) 
    local num1,num2 = math.modf(UICommon.setTimeOffset())
    local m = m + num2 * 60
    if m >= 60 then
        m = m - 60
        h = h + 1
     end

     if m < 0 then
        m = 60 - m
        h = h - 1
     end

     if h >= 24 then
        h =  h - 24
     end

     if h < 0 then
        h =  h + 24
     end

     return h,m
end

function __Class:getTime( ... )
    local servarTime = self.timeProxy:getTime()
    local h,m = self:setHour(servarTime)
    --local m = tonumber(os.date("%M", servarTime))
    local s = tonumber(os.date("%S", servarTime))
    return h,m,s
end

function __Class:setCount( h , m ) --时间计算
    local h,m,s = self:getTime()
    self.lunshu = self.jdyamen.cfg.lun
    if self.jdyamen.cfg.zd_state == 0 then
        return -2,self.jdyamen.cfg.cd.next
    elseif self.jdyamen.cfg.zd_state == 1 then
        local time = self.jdyamen.cfg.lunshu[self.lunshu].time
        return self:setHour(time),time
    else
        return -1,self.jdyamen.cfg.cd.next
    end
end

return __Class